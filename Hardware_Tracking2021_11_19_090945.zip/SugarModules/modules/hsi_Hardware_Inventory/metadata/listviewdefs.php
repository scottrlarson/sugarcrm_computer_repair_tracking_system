<?php
$module_name = 'hsi_Hardware_Inventory';
$listViewDefs [$module_name] = 
array (
  'HSI_HARDWARE_INVENTORY_CONTACTS_NAME' => 
  array (
    'type' => 'relate',
    'link' => 'hsi_hardware_inventory_contacts',
    'label' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'type' => 'name',
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'MANUFACTURER' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_manufacturer',
    'width' => '10%',
    'default' => true,
  ),
  'MODEL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MODEL',
    'width' => '10%',
    'default' => true,
  ),
  'TYPE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_TYPE',
    'width' => '10%',
    'default' => true,
  ),
  'REQUIRED_USE' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_REQUIRED_USE',
    'width' => '10%',
  ),
  'STATUS' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_STATUS',
    'width' => '10%',
  ),
  'DATE_CHECKED_IN' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_CHECKED_IN',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_CHECKED_OUT' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_CHECKED_OUT',
    'width' => '10%',
    'default' => true,
  ),
  'HSI_HARDWARE_INVENTORY_ACCOUNTS_NAME' => 
  array (
    'type' => 'relate',
    'link' => 'hsi_hardware_inventory_accounts',
    'label' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
  'OPERATING_SYSTEM' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_OPERATING_SYSTEM',
    'width' => '10%',
    'default' => false,
  ),
  'SERVICE_PACK' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_SERVICE_PACK',
    'width' => '10%',
    'default' => false,
  ),
  'PART_NUMBER' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PART_NUMBER',
    'width' => '10%',
    'default' => false,
  ),
  'ARCHITECTURE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_ARCHITECTURE',
    'width' => '10%',
    'default' => false,
  ),
  'SERVICE_TAG' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SERVICE_TAG',
    'width' => '10%',
    'default' => false,
  ),
  'SERIAL_NUMBER' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SERIAL_NUMBER',
    'width' => '10%',
    'default' => false,
  ),
  'OPERATING_SYSTEM_TYPE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_OPERATING_SYSTEM_TYPE',
    'width' => '10%',
    'default' => false,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'width' => '10%',
    'default' => false,
  ),
  'FILE_SYSTEM' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_FILE_SYSTEM',
    'width' => '10%',
    'default' => false,
  ),
  'OPERATING_SYSTEM_CURRENT' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_OPERATING_SYSTEM_CURRENT',
    'width' => '10%',
    'default' => false,
  ),
  'PARTITION_TABLE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_PARTITION_TABLE',
    'width' => '10%',
    'default' => false,
  ),
);
?>
