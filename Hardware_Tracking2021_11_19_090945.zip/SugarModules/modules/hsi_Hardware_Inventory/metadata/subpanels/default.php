<?php
$module_name='hsi_Hardware_Inventory';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'hsi_Hardware_Inventory',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'type' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_TYPE',
      'width' => '10%',
      'default' => true,
    ),
    'manufacturer' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_manufacturer',
      'width' => '10%',
      'default' => true,
    ),
    'model' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_MODEL',
      'width' => '10%',
      'default' => true,
    ),
    'part_number' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_PART_NUMBER',
      'width' => '10%',
      'default' => true,
    ),
    'required_use' => 
    array (
      'type' => 'enum',
      'default' => true,
      'studio' => 'visible',
      'vname' => 'LBL_REQUIRED_USE',
      'width' => '10%',
    ),
    'date_checked_in' => 
    array (
      'type' => 'date',
      'vname' => 'LBL_DATE_CHECKED_IN',
      'width' => '10%',
      'default' => true,
    ),
    'date_checked_out' => 
    array (
      'type' => 'date',
      'vname' => 'LBL_DATE_CHECKED_OUT',
      'width' => '10%',
      'default' => true,
    ),
    'edit_button' => 
    array (
      'widget_class' => 'SubPanelEditButton',
      'module' => 'hsi_Hardware_Inventory',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'hsi_Hardware_Inventory',
      'width' => '5%',
      'default' => true,
    ),
  ),
);