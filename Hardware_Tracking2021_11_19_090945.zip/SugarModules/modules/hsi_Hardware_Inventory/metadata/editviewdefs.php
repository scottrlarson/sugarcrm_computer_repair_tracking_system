<?php
$module_name = 'hsi_Hardware_Inventory';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
    ),
    'panels' => 
    array (
      'lbl_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
          1 => 
          array (
            'name' => 'type',
            'studio' => 'visible',
            'label' => 'LBL_TYPE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'manufacturer',
            'studio' => 'visible',
            'label' => 'LBL_MANUFACTURER',
          ),
          1 => 
          array (
            'name' => 'model',
            'label' => 'LBL_MODEL',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'serial_number',
            'label' => 'LBL_SERIAL_NUMBER',
          ),
          1 => 
          array (
            'name' => 'part_number',
            'label' => 'LBL_PART_NUMBER',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'service_tag',
            'label' => 'LBL_SERVICE_TAG',
          ),
          1 => 
          array (
            'name' => 'partition_table',
            'studio' => 'visible',
            'label' => 'LBL_PARTITION_TABLE',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'operating_system',
            'studio' => 'visible',
            'label' => 'LBL_OPERATING_SYSTEM',
          ),
          1 => 
          array (
            'name' => 'file_system',
            'studio' => 'visible',
            'label' => 'LBL_FILE_SYSTEM',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'operating_system_current',
            'studio' => 'visible',
            'label' => 'LBL_OPERATING_SYSTEM_CURRENT',
          ),
          1 => 
          array (
            'name' => 'operating_system_type',
            'label' => 'LBL_OPERATING_SYSTEM_TYPE',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'architecture',
            'studio' => 'visible',
            'label' => 'LBL_ARCHITECTURE',
          ),
          1 => 
          array (
            'name' => 'service_pack',
            'studio' => 'visible',
            'label' => 'LBL_SERVICE_PACK',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'hsi_hardware_inventory_contacts_name',
          ),
          1 => 
          array (
            'name' => 'hsi_hardware_inventory_accounts_name',
          ),
        ),
      ),
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'required_use',
            'studio' => 'visible',
            'label' => 'LBL_REQUIRED_USE',
          ),
          1 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'date_checked_in',
            'label' => 'LBL_DATE_CHECKED_IN',
          ),
          1 => 
          array (
            'name' => 'date_checked_out',
            'label' => 'LBL_DATE_CHECKED_OUT',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'status',
            'studio' => 'visible',
            'label' => 'LBL_STATUS',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
          ),
        ),
      ),
    ),
  ),
);
?>
