<?php
$module_name = 'hsi_Hardware_Inventory';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'hsi_hardware_inventory_accounts_name' => 
      array (
        'type' => 'relate',
        'link' => 'hsi_hardware_inventory_accounts',
        'label' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'hsi_hardware_inventory_accounts_name',
      ),
      'hsi_hardware_inventory_contacts_name' => 
      array (
        'type' => 'relate',
        'link' => 'hsi_hardware_inventory_contacts',
        'label' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'hsi_hardware_inventory_contacts_name',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'model' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_MODEL',
        'width' => '10%',
        'default' => true,
        'name' => 'model',
      ),
      'manufacturer' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_manufacturer',
        'width' => '10%',
        'default' => true,
        'name' => 'manufacturer',
      ),
      'service_tag' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_SERVICE_TAG',
        'width' => '10%',
        'default' => true,
        'name' => 'service_tag',
      ),
      'part_number' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PART_NUMBER',
        'width' => '10%',
        'default' => true,
        'name' => 'part_number',
      ),
      'serial_number' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_SERIAL_NUMBER',
        'width' => '10%',
        'default' => true,
        'name' => 'serial_number',
      ),
      'current_user_only' => 
      array (
        'name' => 'current_user_only',
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
        'default' => true,
        'width' => '10%',
      ),
    ),
    'advanced_search' => 
    array (
      'hsi_hardware_inventory_accounts_name' => 
      array (
        'type' => 'relate',
        'link' => 'hsi_hardware_inventory_accounts',
        'label' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'hsi_hardware_inventory_accounts_name',
      ),
      'hsi_hardware_inventory_contacts_name' => 
      array (
        'type' => 'relate',
        'link' => 'hsi_hardware_inventory_contacts',
        'label' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'hsi_hardware_inventory_contacts_name',
      ),
      'manufacturer' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_manufacturer',
        'width' => '10%',
        'default' => true,
        'name' => 'manufacturer',
      ),
      'model' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_MODEL',
        'width' => '10%',
        'default' => true,
        'name' => 'model',
      ),
      'serial_number' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_SERIAL_NUMBER',
        'width' => '10%',
        'default' => true,
        'name' => 'serial_number',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'service_tag' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_SERVICE_TAG',
        'width' => '10%',
        'default' => true,
        'name' => 'service_tag',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'default' => true,
        'width' => '10%',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
