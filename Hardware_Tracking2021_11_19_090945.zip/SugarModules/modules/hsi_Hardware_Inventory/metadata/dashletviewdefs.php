<?php
$dashletData['hsi_Hardware_System_InformationDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'type' => 
  array (
    'default' => '',
  ),
  'manufacturer' => 
  array (
    'default' => '',
  ),
  'model' => 
  array (
    'default' => '',
  ),
  'date_entered' => 
  array (
    'default' => '',
  ),
  'date_modified' => 
  array (
    'default' => '',
  ),
);
$dashletData['hsi_Hardware_System_InformationDashlet']['columns'] = array (
  'name' => 
  array (
    'type' => 'name',
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'type' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_TYPE',
    'width' => '10%',
    'default' => true,
    'name' => 'type',
  ),
  'manufacturer' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_MANUFACTURER',
    'width' => '10%',
    'default' => true,
    'name' => 'manufacturer',
  ),
  'model' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MODEL',
    'width' => '10%',
    'default' => true,
    'name' => 'model',
  ),
  'service_tag' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SERVICE_TAG',
    'width' => '10%',
    'default' => true,
    'name' => 'service_tag',
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => true,
    'name' => 'date_entered',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => true,
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => false,
  ),
);
