<?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
$dictionary['hsi_Hardware_Inventory'] = array(
	'table'=>'hsi_hardware_inventory',
	'audited'=>true,
	'fields'=>array (
  'type' => 
  array (
    'required' => '1',
    'name' => 'type',
    'vname' => 'LBL_TYPE',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'hardware_type_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'manufacturer' => 
  array (
    'required' => '1',
    'name' => 'manufacturer',
    'vname' => 'LBL_manufacturer',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'manufacturer_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'model' => 
  array (
    'required' => false,
    'name' => 'model',
    'vname' => 'LBL_MODEL',
    'type' => 'varchar',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => '50',
  ),
  'serial_number' => 
  array (
    'required' => false,
    'name' => 'serial_number',
    'vname' => 'LBL_SERIAL_NUMBER',
    'type' => 'varchar',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 0,
    'reportable' => 0,
    'len' => '50',
  ),
  'service_tag' => 
  array (
    'required' => false,
    'name' => 'service_tag',
    'vname' => 'LBL_SERVICE_TAG',
    'type' => 'varchar',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 0,
    'reportable' => 0,
    'len' => '25',
  ),
  'operating_system' => 
  array (
    'required' => false,
    'name' => 'operating_system',
    'vname' => 'LBL_OPERATING_SYSTEM',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'operating_system_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'service_pack' => 
  array (
    'required' => false,
    'name' => 'service_pack',
    'vname' => 'LBL_SERVICE_PACK',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'service_pack_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'hsi_hardware_system_information_id_c' => 
  array (
    'required' => false,
    'name' => 'hsi_hardware_system_information_id_c',
    'vname' => '',
    'type' => 'id',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => 0,
    'audited' => 0,
    'reportable' => 0,
    'len' => 36,
  ),
  'required_use' => 
  array (
    'required' => false,
    'name' => 'required_use',
    'vname' => 'LBL_REQUIRED_USE',
    'type' => 'enum',
    'massupdate' => '1',
    'default' => 'Servicing Equipment',
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'required_use_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'date_checked_in' => 
  array (
    'required' => false,
    'name' => 'date_checked_in',
    'vname' => 'LBL_DATE_CHECKED_IN',
    'type' => 'date',
    'massupdate' => '1',
    'comments' => '',
    'help' => 'Date the equipment was checked in',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'display_default' => 'now',
  ),
  'date_checked_out' => 
  array (
    'required' => false,
    'name' => 'date_checked_out',
    'vname' => 'LBL_DATE_CHECKED_OUT',
    'type' => 'date',
    'massupdate' => '1',
    'comments' => '',
    'help' => 'Date equipment was checked out',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
  ),
  'architecture' => 
  array (
    'required' => false,
    'name' => 'architecture',
    'vname' => 'LBL_ARCHITECTURE',
    'type' => 'enum',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'architecture_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'part_number' => 
  array (
    'required' => false,
    'name' => 'part_number',
    'vname' => 'LBL_PART_NUMBER',
    'type' => 'varchar',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 0,
    'reportable' => 0,
    'len' => '25',
  ),
  'operating_system_type' => 
  array (
    'required' => false,
    'name' => 'operating_system_type',
    'vname' => 'LBL_OPERATING_SYSTEM_TYPE',
    'type' => 'varchar',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 0,
    'reportable' => 0,
    'len' => '255',
  ),
  'status' => 
  array (
    'required' => '1',
    'name' => 'status',
    'vname' => 'LBL_STATUS',
    'type' => 'enum',
    'massupdate' => 0,
    'default' => 'Servicing',
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 0,
    'reportable' => 0,
    'len' => 100,
    'options' => 'status_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'file_system' => 
  array (
    'required' => false,
    'name' => 'file_system',
    'vname' => 'LBL_FILE_SYSTEM',
    'type' => 'enum',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 0,
    'reportable' => 0,
    'len' => 100,
    'options' => 'file_system_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'operating_system_current' => 
  array (
    'required' => false,
    'name' => 'operating_system_current',
    'vname' => 'LBL_OPERATING_SYSTEM_CURRENT',
    'type' => 'enum',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 0,
    'reportable' => 0,
    'len' => 100,
    'options' => 'operating_system_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'partition_table' => 
  array (
    'required' => false,
    'name' => 'partition_table',
    'vname' => 'LBL_PARTITION_TABLE',
    'type' => 'enum',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 0,
    'reportable' => 0,
    'len' => 100,
    'options' => 'partition_table_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
),
	'relationships'=>array (
),
	'optimistic_lock'=>true,
);
if (!class_exists('VardefManager')){
        require_once('include/SugarObjects/VardefManager.php');
}
VardefManager::createVardef('hsi_Hardware_Inventory','hsi_Hardware_Inventory', array('basic','assignable'));