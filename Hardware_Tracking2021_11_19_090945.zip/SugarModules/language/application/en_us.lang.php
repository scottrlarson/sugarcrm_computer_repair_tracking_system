<?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

$app_list_strings['moduleList']['hsi_Hardware_Inventory'] = 'Hardware Inventory';
$app_list_strings['hardware']['Desktop'] = 'Desktop';
$app_list_strings['hardware']['Laptop'] = 'Laptop';
$app_list_strings['hardware']['Netbook'] = 'Netbook';
$app_list_strings['hardware']['Tablet'] = 'Tablet';
$app_list_strings['hardware']['Portable'] = 'Portable';
$app_list_strings['hardware']['Device'] = 'Device';
$app_list_strings['hardware']['Interface Card'] = 'Interface Card';
$app_list_strings['hardware']['External Device'] = 'External Device';
$app_list_strings['hardware']['Internal Device'] = 'Internal Device';
$app_list_strings['hardware'][''] = '';
$app_list_strings['manufacturer_list'][''] = '';
$app_list_strings['manufacturer_list']['Acer'] = 'Acer';
$app_list_strings['manufacturer_list']['Apple'] = 'Apple';
$app_list_strings['manufacturer_list']['Asus'] = 'Asus';
$app_list_strings['manufacturer_list']['Cannon'] = 'Cannon';
$app_list_strings['manufacturer_list']['Custom'] = 'Custom';
$app_list_strings['manufacturer_list']['Dell'] = 'Dell';
$app_list_strings['manufacturer_list']['Gateway'] = 'Gateway';
$app_list_strings['manufacturer_list']['Hitachi'] = 'Hitachi';
$app_list_strings['manufacturer_list']['HP'] = 'HP';
$app_list_strings['manufacturer_list']['IBM'] = 'IBM';
$app_list_strings['manufacturer_list']['Intel'] = 'Intel';
$app_list_strings['manufacturer_list']['IOGEAR'] = 'IOGEAR';
$app_list_strings['manufacturer_list']['Kensington'] = 'Kensigton';
$app_list_strings['manufacturer_list']['Kingston'] = 'Kingston';
$app_list_strings['manufacturer_list']['LaCie'] = 'LaCie';
$app_list_strings['manufacturer_list']['Lenovo'] = 'Lenovo';
$app_list_strings['manufacturer_list']['Lexar'] = 'Lexar';
$app_list_strings['manufacturer_list']['Linksys'] = 'Linksys';
$app_list_strings['manufacturer_list']['Lite-On'] = 'Lite-On';
$app_list_strings['manufacturer_list']['LSI'] = 'LSI';
$app_list_strings['manufacturer_list']['NEC'] = 'NEC';
$app_list_strings['manufacturer_list']['Netgear'] = 'Netgear';
$app_list_strings['manufacturer_list']['Other'] = 'Other';
$app_list_strings['manufacturer_list']['Samsung'] = 'Samsung';
$app_list_strings['manufacturer_list']['Sandisk'] = 'Sandisk';
$app_list_strings['manufacturer_list']['Segate'] = 'Segate';
$app_list_strings['manufacturer_list']['Sony'] = 'Sony';
$app_list_strings['manufacturer_list']['Toshiba'] = 'Toshiba';
$app_list_strings['manufacturer_list']['Wester Digital'] = 'Wester Digital';
$app_list_strings['operating_system_list'][''] = '';
$app_list_strings['operating_system_list']['Windows XP'] = 'Windows XP';
$app_list_strings['operating_system_list']['Windows Vista'] = 'Windows Vista';
$app_list_strings['operating_system_list']['Windows 7'] = 'Windows 7';
$app_list_strings['operating_system_list']['Windows Mobile'] = 'Windows Mobile';
$app_list_strings['operating_system_list']['Apple OS'] = 'Apple OS';
$app_list_strings['operating_system_list']['Andriod'] = 'Andriod';
$app_list_strings['operating_system_list']['Linux'] = 'Linux';
$app_list_strings['operating_system_list']['Other'] = 'Other';
$app_list_strings['service_pack_list'][''] = '';
$app_list_strings['service_pack_list']['SP1'] = 'SP1';
$app_list_strings['service_pack_list']['SP2'] = 'SP2';
$app_list_strings['service_pack_list']['SP3'] = 'SP3';
$app_list_strings['service_pack_list']['SP4'] = 'SP4';
$app_list_strings['service_pack_list']['SP5'] = 'SP5';
$app_list_strings['required_use_list']['Servicing Equipment'] = 'Servicing Equipment';
$app_list_strings['required_use_list']['Backup Device'] = 'Backup Device';
$app_list_strings['required_use_list']['Recycle Part'] = 'Recycle Part';
$app_list_strings['required_use_list']['Upgrade Part'] = 'Upgrade Part';
$app_list_strings['hardware_list']['Battery'] = 'Battery';
$app_list_strings['hardware_list']['Boot Cycle'] = 'Boot Cycle';
$app_list_strings['hardware_list']['Cable'] = 'Cable';
$app_list_strings['hardware_list']['Capacitor'] = 'Capacitor';
$app_list_strings['hardware_list']['Case'] = 'Case';
$app_list_strings['hardware_list']['Computer'] = 'Computer';
$app_list_strings['hardware_list']['Connection'] = 'Connection';
$app_list_strings['hardware_list']['CPU'] = 'CPU';
$app_list_strings['hardware_list']['Dial-In Modem'] = 'Dial-In Modem';
$app_list_strings['hardware_list']['Display'] = 'Display';
$app_list_strings['hardware_list']['Fan'] = 'Fan';
$app_list_strings['hardware_list']['Firewall'] = 'Firewall';
$app_list_strings['hardware_list']['Firewire-Device'] = 'Firewire-Device';
$app_list_strings['hardware_list']['Firewire-Port'] = 'Firewire-Port';
$app_list_strings['hardware_list']['Hard Disk'] = 'Hard Disk';
$app_list_strings['hardware_list']['Internal-Wiring'] = 'Internal-Wiring';
$app_list_strings['hardware_list']['Inverter'] = 'Inverter';
$app_list_strings['hardware_list']['Keyboard'] = 'Keyboard';
$app_list_strings['hardware_list']['Lights'] = 'Lights';
$app_list_strings['hardware_list']['Memory'] = 'Memory';
$app_list_strings['hardware_list']['Modem '] = 'Modem';
$app_list_strings['hardware_list']['Motherboard'] = 'Motherboard';
$app_list_strings['hardware_list']['Network'] = 'Network';
$app_list_strings['hardware_list']['Optical'] = 'Optical';
$app_list_strings['hardware_list']['Pointing Device'] = 'Pointing Device';
$app_list_strings['hardware_list']['Power Connector'] = 'Power Connector';
$app_list_strings['hardware_list']['Power Pupply'] = 'Power Pupply';
$app_list_strings['hardware_list']['Power-Switch'] = 'Power-Switch';
$app_list_strings['hardware_list']['Printer'] = 'Printer';
$app_list_strings['hardware_list']['Router'] = 'Router';
$app_list_strings['hardware_list']['Socket'] = 'Socket';
$app_list_strings['hardware_list']['Sound'] = 'Sound';
$app_list_strings['hardware_list']['Speakers'] = 'Speakers';
$app_list_strings['hardware_list']['System'] = 'System';
$app_list_strings['hardware_list']['USB-Device'] = 'USB-Device';
$app_list_strings['hardware_list']['USB-port'] = 'USB-port';
$app_list_strings['hardware_list']['Video'] = 'Video';
$app_list_strings['hardware_list']['Wireless-Antena'] = 'Wireless-Antena';
$app_list_strings['hardware_list']['Wireless-Device'] = 'Wireless-Device';
$app_list_strings['hardware_list']['Wiring'] = 'Wiring';
$app_list_strings['hardware_list'][''] = '';
$app_list_strings['architecture_list']['x86'] = 'x86';
$app_list_strings['architecture_list']['x64'] = 'x64';
$app_list_strings['architecture_list'][''] = '';
$app_list_strings['status_list']['Servicing'] = 'Servicing';
$app_list_strings['status_list']['Customer Picked-up '] = 'Customer Picked-up ';
$app_list_strings['status_list']['Tech Delivered'] = 'Tech Delivered';
$app_list_strings['status_list']['Shipped'] = 'Shipped';
$app_list_strings['status_list']['Recycled'] = 'Recycled';
$app_list_strings['status_list']['Abandoned'] = 'Abandoned';
$app_list_strings['file_system_list']['FAT32'] = 'FAT32';
$app_list_strings['file_system_list']['NTFS'] = 'NTFS';
$app_list_strings['file_system_list']['HFS'] = 'HFS';
$app_list_strings['file_system_list']['HFS+'] = 'HFS+';
$app_list_strings['file_system_list']['EXT2'] = 'EXT2';
$app_list_strings['file_system_list']['EXT3'] = 'EXT3';
$app_list_strings['file_system_list']['EXT4'] = 'EXT4';
$app_list_strings['file_system_list'][''] = '';
$app_list_strings['partition_table_list']['APM'] = 'APM';
$app_list_strings['partition_table_list']['EFI GPT'] = 'EFI GPT';
$app_list_strings['partition_table_list']['GPT'] = 'GPT';
$app_list_strings['partition_table_list'][''] = '';
$app_list_strings['feature_release_win10']['1809'] = '1809';
$app_list_strings['feature_release_win10']['1909'] = '1909';
$app_list_strings['feature_release_win10']['2004'] = '2004';
$app_list_strings['feature_release_win10']['20H2'] = '20H2';
$app_list_strings['feature_release_win10']['21H1'] = '21H1';
$app_list_strings['feature_release_win10'][''] = '';
$app_list_strings['hardware_type_list'][''] = '';
$app_list_strings['hardware_type_list']['All-In-One'] = 'All-In-One';
$app_list_strings['hardware_type_list']['Appliance'] = 'Appliance';
$app_list_strings['hardware_type_list']['Card'] = 'Card';
$app_list_strings['hardware_type_list']['Desktop'] = 'Desktop';
$app_list_strings['hardware_type_list']['Device'] = 'Device';
$app_list_strings['hardware_type_list']['Display'] = 'Display';
$app_list_strings['hardware_type_list']['Drive'] = 'Drive';
$app_list_strings['hardware_type_list']['Ipad'] = 'Ipad';
$app_list_strings['hardware_type_list']['Laptop'] = 'Laptop';
$app_list_strings['hardware_type_list']['Mac Desktop'] = 'Mac Desktop';
$app_list_strings['hardware_type_list']['Mac Laptop'] = 'Mac Laptop';
$app_list_strings['hardware_type_list']['Mini-PC'] = 'Mini-PC';
$app_list_strings['hardware_type_list']['Netbook'] = 'Netbook';
$app_list_strings['hardware_type_list']['Printer'] = 'Printer';
$app_list_strings['hardware_type_list']['Slim-PC'] = 'Slim-PC';
$app_list_strings['hardware_type_list']['Tablet'] = 'Tablet';
$app_list_strings['hardware_type_list']['Tower-Full'] = 'Tower-Full';
$app_list_strings['hardware_type_list']['Tower-Med'] = 'Tower-Med';
$app_list_strings['hardware_type_list']['Tower-Mini'] = 'Tower-Mini';
$app_list_strings['account_type_dom'][''] = '';
$app_list_strings['account_type_dom']['Analyst'] = 'Analyst';
$app_list_strings['account_type_dom']['Competitor'] = 'Competitor';
$app_list_strings['account_type_dom']['Customer'] = 'Customer';
$app_list_strings['account_type_dom']['Intergrator'] = 'Intergrator';
$app_list_strings['account_type_dom']['Investor'] = 'Investor';
$app_list_strings['account_type_dom']['Partner'] = 'Partner';
$app_list_strings['account_type_dom']['Press'] = 'Press';
$app_list_strings['account_type_dom']['Prospect'] = 'Prospect';
$app_list_strings['account_type_dom']['Reseller'] = 'Reseller';
$app_list_strings['account_type_dom']['Other'] = 'Other';
$app_list_strings['account_type_dom']['Website Customer'] = 'Website Consulting Customer';
$app_list_strings['account_type_dom']['Computer Service Customer'] = 'Computer Service Customer';
$app_list_strings['account_type_dom']['Video/Audio Customer'] = 'Video/Audio Consulting Customer';
$app_list_strings['account_type_dom']['Education'] = 'Education';
