<?php
// created: 2021-11-19 09:09:45
$dictionary["hsi_hardware_inventory_contacts"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'hsi_hardware_inventory_contacts' => 
    array (
      'lhs_module' => 'Contacts',
      'lhs_table' => 'contacts',
      'lhs_key' => 'id',
      'rhs_module' => 'hsi_Hardware_Inventory',
      'rhs_table' => 'hsi_hardware_inventory',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'hsi_hardwarory_contacts_c',
      'join_key_lhs' => 'hsi_hardwae7daontacts_ida',
      'join_key_rhs' => 'hsi_hardwa4b02ventory_idb',
    ),
  ),
  'table' => 'hsi_hardwarory_contacts_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'hsi_hardwae7daontacts_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'hsi_hardwa4b02ventory_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'hsi_hardwarntory_contactsspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'hsi_hardwarntory_contacts_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'hsi_hardwae7daontacts_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'hsi_hardwarntory_contacts_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'hsi_hardwa4b02ventory_idb',
      ),
    ),
  ),
);
?>
