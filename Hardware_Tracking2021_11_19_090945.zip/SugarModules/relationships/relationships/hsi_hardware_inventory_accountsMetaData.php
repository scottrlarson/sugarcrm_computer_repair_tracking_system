<?php
// created: 2021-11-19 09:09:45
$dictionary["hsi_hardware_inventory_accounts"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'hsi_hardware_inventory_accounts' => 
    array (
      'lhs_module' => 'Accounts',
      'lhs_table' => 'accounts',
      'lhs_key' => 'id',
      'rhs_module' => 'hsi_Hardware_Inventory',
      'rhs_table' => 'hsi_hardware_inventory',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'hsi_hardwarory_accounts_c',
      'join_key_lhs' => 'hsi_hardwa4fb5ccounts_ida',
      'join_key_rhs' => 'hsi_hardwaa817ventory_idb',
    ),
  ),
  'table' => 'hsi_hardwarory_accounts_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'hsi_hardwa4fb5ccounts_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'hsi_hardwaa817ventory_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'hsi_hardwarntory_accountsspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'hsi_hardwarntory_accounts_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'hsi_hardwa4fb5ccounts_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'hsi_hardwarntory_accounts_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'hsi_hardwaa817ventory_idb',
      ),
    ),
  ),
);
?>
