<?php
// created: 2012-02-15 17:12:05
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 17:15:16
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 17:16:41
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 17:20:09
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 20:14:26
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 20:16:33
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 20:41:58
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 20:43:57
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 20:44:47
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 20:46:40
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 20:56:00
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 20:56:06
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 20:56:17
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-23 15:46:53
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-17 14:31:38
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-05-08 12:42:12
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-05-11 15:02:37
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-07-31 13:44:39
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-07-31 13:44:45
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-11 12:59:58
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-11 13:00:04
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-17 13:07:15
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-17 13:08:41
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-26 14:08:47
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2013-10-31 11:05:10
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2013-10-31 11:07:05
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2013-12-06 14:54:24
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-06-04 12:11:20
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-06-04 12:14:00
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-06-17 13:30:27
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-06-17 13:35:37
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-08-30 09:08:24
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-11-19 09:09:45
$layout_defs["Contacts"]["subpanel_setup"]["hsi_hardware_inventory_contacts"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'hsi_hardware_inventory_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
