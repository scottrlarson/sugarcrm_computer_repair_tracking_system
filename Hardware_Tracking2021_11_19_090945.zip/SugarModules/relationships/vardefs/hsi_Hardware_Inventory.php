<?php
// created: 2012-02-15 17:12:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 17:12:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 17:12:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 17:12:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 17:12:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 17:12:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 17:15:16
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 17:15:16
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 17:15:16
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 17:15:16
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 17:15:16
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 17:15:16
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 17:16:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 17:16:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 17:16:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 17:16:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 17:16:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 17:16:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 17:20:09
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 17:20:09
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 17:20:09
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 17:20:09
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 17:20:09
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 17:20:09
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:14:26
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:14:26
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:14:26
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:14:27
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:14:27
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:14:27
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:16:33
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:16:33
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:16:33
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:16:33
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:16:33
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:16:33
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:41:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:41:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:41:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:41:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:41:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:41:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:43:57
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:43:57
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:43:57
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:43:57
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:43:57
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:43:57
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:44:47
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:44:47
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:44:47
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:44:47
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:44:47
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:44:47
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:46:40
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:46:40
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:46:40
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:46:40
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:46:40
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:46:40
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:56:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:56:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:56:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:56:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:56:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:56:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:56:06
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:56:06
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:56:06
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:56:06
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:56:06
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:56:06
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:56:17
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:56:17
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:56:17
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-02-15 20:56:17
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:56:17
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:56:17
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-03-23 15:46:53
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-23 15:46:53
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-23 15:46:53
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-03-23 15:46:53
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-23 15:46:53
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-23 15:46:53
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-04-17 14:31:38
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-04-17 14:31:38
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-17 14:31:38
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-04-17 14:31:38
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-04-17 14:31:38
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-04-17 14:31:38
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-05-08 12:42:12
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-05-08 12:42:12
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-05-08 12:42:12
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-05-08 12:42:12
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-05-08 12:42:12
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-05-08 12:42:12
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-05-11 15:02:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-05-11 15:02:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-05-11 15:02:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-05-11 15:02:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-05-11 15:02:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-05-11 15:02:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:39
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:39
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-07-31 13:44:39
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:39
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:39
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-07-31 13:44:39
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:45
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:45
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-07-31 13:44:45
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:46
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:46
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-07-31 13:44:46
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:59:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-11 12:59:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-11 13:00:04
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-11 13:00:04
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 13:00:04
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-11 13:00:04
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-11 13:00:04
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-11 13:00:04
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-17 13:07:15
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-17 13:07:15
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-17 13:07:15
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-17 13:07:15
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-17 13:07:15
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-17 13:07:15
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-17 13:08:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-17 13:08:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-17 13:08:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-17 13:08:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-17 13:08:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-17 13:08:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-26 14:08:48
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-26 14:08:48
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-26 14:08:48
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-26 14:08:48
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-26 14:08:48
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-26 14:08:48
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2013-10-31 11:05:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2013-10-31 11:05:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2013-10-31 11:05:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2013-10-31 11:05:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2013-10-31 11:05:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2013-10-31 11:05:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2013-10-31 11:07:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2013-10-31 11:07:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2013-10-31 11:07:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2013-10-31 11:07:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2013-10-31 11:07:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2013-10-31 11:07:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2013-12-06 14:54:24
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2013-12-06 14:54:24
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2013-12-06 14:54:24
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2013-12-06 14:54:25
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2013-12-06 14:54:25
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2013-12-06 14:54:25
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2014-06-04 12:11:20
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2014-06-04 12:11:20
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2014-06-04 12:11:20
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2014-06-04 12:11:20
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2014-06-04 12:11:20
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2014-06-04 12:11:20
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2014-06-04 12:14:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2014-06-04 12:14:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-06-17 13:30:27
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-06-17 13:30:27
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-06-17 13:30:27
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-06-17 13:30:27
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-06-17 13:30:27
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-06-17 13:30:27
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-06-17 13:35:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-06-17 13:35:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-06-17 13:35:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-06-17 13:35:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-06-17 13:35:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-06-17 13:35:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-08-30 09:08:24
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-08-30 09:08:24
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-08-30 09:08:24
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-08-30 09:08:24
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-08-30 09:08:24
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-08-30 09:08:24
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-11-19 09:09:45
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts"] = array (
  'name' => 'hsi_hardware_inventory_accounts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-11-19 09:09:45
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_accounts_name"] = array (
  'name' => 'hsi_hardware_inventory_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwa4fb5ccounts_ida',
  'link' => 'hsi_hardware_inventory_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-19 09:09:45
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwa4fb5ccounts_ida"] = array (
  'name' => 'hsi_hardwa4fb5ccounts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_ACCOUNTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-11-19 09:09:45
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts"] = array (
  'name' => 'hsi_hardware_inventory_contacts',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-11-19 09:09:45
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardware_inventory_contacts_name"] = array (
  'name' => 'hsi_hardware_inventory_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'hsi_hardwae7daontacts_ida',
  'link' => 'hsi_hardware_inventory_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-11-19 09:09:45
$dictionary["hsi_Hardware_Inventory"]["fields"]["hsi_hardwae7daontacts_ida"] = array (
  'name' => 'hsi_hardwae7daontacts_ida',
  'type' => 'link',
  'relationship' => 'hsi_hardware_inventory_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_HSI_HARDWARE_INVENTORY_CONTACTS_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
