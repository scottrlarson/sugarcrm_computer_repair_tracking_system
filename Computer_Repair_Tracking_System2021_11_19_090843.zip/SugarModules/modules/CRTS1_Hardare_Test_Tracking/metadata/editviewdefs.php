<?php
$module_name = 'CRTS1_Hardare_Test_Tracking';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
          1 => 
          array (
            'name' => 'htt_test_date',
            'label' => 'LBL_HTT_TEST_DATE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
          1 => '',
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'crts1_hardare_test_tracking_accounts_name',
          ),
          1 => '',
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'htt_diag_status',
            'studio' => 'visible',
            'label' => 'LBL_HTT_DIAG_STATUS',
          ),
          1 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'test_type',
            'studio' => 'visible',
            'label' => 'LBL_TEST_TYPE',
          ),
          1 => '',
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'crts1_hardare_test_tracking_contacts_name',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'crts1_hardare_test_tracking_hsi_hardware_inventory_name',
          ),
        ),
      ),
      'lbl_panel12' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'power_supply',
            'studio' => 'visible',
            'label' => 'LBL_POWER_SUPPLY',
          ),
          1 => '',
        ),
      ),
      'lbl_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'htt_motherboard_tests',
            'studio' => 'visible',
            'label' => 'LBL_HTT_MOTHERBOARD_TESTS',
          ),
          1 => 
          array (
            'name' => 'htt_mb_fan_test',
            'studio' => 'visible',
            'label' => 'LBL_HTT_MB_FAN_TEST',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'htt_usb_tests',
            'studio' => 'visible',
            'label' => 'LBL_HTT_USB_TESTS',
          ),
          1 => '',
        ),
      ),
      'lbl_panel5' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'htt_processor_test',
            'studio' => 'visible',
            'label' => 'LBL_HTT_PROCESSOR_TEST',
          ),
          1 => 
          array (
            'name' => 'htt_processor_fan',
            'studio' => 'visible',
            'label' => 'LBL_HTT_PROCESSOR_FAN',
          ),
        ),
      ),
      'lbl_panel6' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'htt_ram_test',
            'studio' => 'visible',
            'label' => 'LBL_HTT_RAM_TEST',
          ),
          1 => 
          array (
            'name' => 'htt_cache_test',
            'studio' => 'visible',
            'label' => 'LBL_HTT_CACHE_TEST',
          ),
        ),
      ),
      'lbl_panel7' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'htt_video_tests',
            'studio' => 'visible',
            'label' => 'LBL_HTT_VIDEO_TESTS',
          ),
          1 => 
          array (
            'name' => 'htt_video_memory_test',
            'studio' => 'visible',
            'label' => 'LBL_HTT_VIDEO_MEMORY_TEST',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'htt_monitor_tests',
            'studio' => 'visible',
            'label' => 'LBL_HTT_MONITOR_TESTS',
          ),
          1 => '',
        ),
      ),
      'lbl_panel8' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'htt_hard_disk_test',
            'studio' => 'visible',
            'label' => 'LBL_HTT_HARD_DISK_TEST',
          ),
          1 => 
          array (
            'name' => 'htt_optical_drive_test',
            'studio' => 'visible',
            'label' => 'LBL_HTT_OPTICAL_DRIVE_TEST',
          ),
        ),
      ),
      'lbl_panel9' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'htt_sound_tests',
            'studio' => 'visible',
            'label' => 'LBL_HTT_SOUND_TESTS',
          ),
        ),
      ),
      'lbl_panel10' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'htt_printer_test',
            'studio' => 'visible',
            'label' => 'LBL_HTT_PRINTER_TEST',
          ),
          1 => 
          array (
            'name' => 'htt_scanner_test',
            'studio' => 'visible',
            'label' => 'LBL_HTT_SCANNER_TEST',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'htt_fax_test',
            'studio' => 'visible',
            'label' => 'Does the Faxing operation function?',
          ),
          1 => '',
        ),
      ),
      'lbl_panel11' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'htt_stress_test',
            'studio' => 'visible',
            'label' => 'LBL_HTT_STRESS_TEST',
          ),
          1 => 
          array (
            'name' => 'htt_hardware_temp',
            'studio' => 'visible',
            'label' => 'LBL_HTT_HARDWARE_TEMP',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'htt_battery_test',
            'studio' => 'visible',
            'label' => 'LBL_HTT_BATTERY_TEST',
          ),
          1 => '',
        ),
      ),
    ),
  ),
);
?>
