<?php
$dashletData['CRTS1_Hardare_Test_TrackingDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'htt_diag_status' => 
  array (
    'default' => '',
  ),
  'htt_test_date' => 
  array (
    'default' => '',
  ),
  'date_entered' => 
  array (
    'default' => '',
  ),
  'date_modified' => 
  array (
    'default' => '',
  ),
);
$dashletData['CRTS1_Hardare_Test_TrackingDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => true,
  ),
  'htt_diag_status' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_HTT_DIAG_STATUS',
    'width' => '10%',
    'default' => true,
    'name' => 'htt_diag_status',
  ),
  'htt_test_date' => 
  array (
    'type' => 'date',
    'label' => 'LBL_HTT_TEST_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
);
