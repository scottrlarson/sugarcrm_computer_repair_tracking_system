<?php
$module_name = 'CRTS1_Hardare_Test_Tracking';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'crts1_hardare_test_tracking_accounts_name' => 
      array (
        'type' => 'relate',
        'link' => 'crts1_hardare_test_tracking_accounts',
        'label' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'crts1_hardare_test_tracking_accounts_name',
      ),
      'crts1_hardare_test_tracking_contacts_name' => 
      array (
        'type' => 'relate',
        'link' => 'crts1_hardare_test_tracking_contacts',
        'label' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'crts1_hardare_test_tracking_contacts_name',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'htt_diag_status' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_HTT_DIAG_STATUS',
        'width' => '10%',
        'default' => true,
        'name' => 'htt_diag_status',
      ),
      'htt_test_date' => 
      array (
        'type' => 'date',
        'label' => 'LBL_HTT_TEST_DATE',
        'width' => '10%',
        'default' => true,
        'name' => 'htt_test_date',
      ),
      'current_user_only' => 
      array (
        'name' => 'current_user_only',
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
        'default' => true,
        'width' => '10%',
      ),
    ),
    'advanced_search' => 
    array (
      'htt_motherboard_tests' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_MOTHERBOARD_TESTS',
        'width' => '10%',
        'name' => 'htt_motherboard_tests',
      ),
      'htt_ram_test' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_RAM_TEST',
        'width' => '10%',
        'name' => 'htt_ram_test',
      ),
      'crts1_hardare_test_tracking_contacts_name' => 
      array (
        'type' => 'relate',
        'link' => 'crts1_hardare_test_tracking_contacts',
        'label' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'crts1_hardare_test_tracking_contacts_name',
      ),
      'crts1_hardare_test_tracking_accounts_name' => 
      array (
        'type' => 'relate',
        'link' => 'crts1_hardare_test_tracking_accounts',
        'label' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'crts1_hardare_test_tracking_accounts_name',
      ),
      'htt_diag_status' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_HTT_DIAG_STATUS',
        'width' => '10%',
        'default' => true,
        'name' => 'htt_diag_status',
      ),
      'htt_video_memory_test' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_VIDEO_MEMORY_TEST',
        'width' => '10%',
        'name' => 'htt_video_memory_test',
      ),
      'htt_battery_test' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_BATTERY_TEST',
        'width' => '10%',
        'name' => 'htt_battery_test',
      ),
      'htt_hardware_temp' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_HARDWARE_TEMP',
        'width' => '10%',
        'name' => 'htt_hardware_temp',
      ),
      'htt_stress_test' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_STRESS_TEST',
        'width' => '10%',
        'name' => 'htt_stress_test',
      ),
      'htt_fax_test' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'Does the Faxing operation function?',
        'width' => '10%',
        'name' => 'htt_fax_test',
      ),
      'htt_scanner_test' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_SCANNER_TEST',
        'width' => '10%',
        'name' => 'htt_scanner_test',
      ),
      'htt_printer_test' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_PRINTER_TEST',
        'width' => '10%',
        'name' => 'htt_printer_test',
      ),
      'htt_sound_tests' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_SOUND_TESTS',
        'width' => '10%',
        'name' => 'htt_sound_tests',
      ),
      'htt_optical_drive_test' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_OPTICAL_DRIVE_TEST',
        'width' => '10%',
        'name' => 'htt_optical_drive_test',
      ),
      'htt_hard_disk_test' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_HARD_DISK_TEST',
        'width' => '10%',
        'name' => 'htt_hard_disk_test',
      ),
      'htt_monitor_tests' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_MONITOR_TESTS',
        'width' => '10%',
        'name' => 'htt_monitor_tests',
      ),
      'htt_video_tests' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_VIDEO_TESTS',
        'width' => '10%',
        'name' => 'htt_video_tests',
      ),
      'htt_cache_test' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_CACHE_TEST',
        'width' => '10%',
        'name' => 'htt_cache_test',
      ),
      'htt_processor_fan' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_PROCESSOR_FAN',
        'width' => '10%',
        'name' => 'htt_processor_fan',
      ),
      'htt_usb_tests' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_USB_TESTS',
        'width' => '10%',
        'name' => 'htt_usb_tests',
      ),
      'htt_processor_test' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_PROCESSOR_TEST',
        'width' => '10%',
        'name' => 'htt_processor_test',
      ),
      'htt_mb_fan_test' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_HTT_MB_FAN_TEST',
        'width' => '10%',
        'name' => 'htt_mb_fan_test',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'date_modified' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_modified',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'default' => true,
        'width' => '10%',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
