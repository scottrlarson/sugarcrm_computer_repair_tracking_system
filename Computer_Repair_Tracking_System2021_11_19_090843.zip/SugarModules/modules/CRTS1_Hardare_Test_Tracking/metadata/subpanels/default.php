<?php
$module_name='CRTS1_Hardare_Test_Tracking';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'CRTS1_Hardare_Test_Tracking',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'test_type' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_TEST_TYPE',
      'width' => '10%',
      'default' => true,
    ),
    'htt_test_date' => 
    array (
      'type' => 'date',
      'vname' => 'LBL_HTT_TEST_DATE',
      'width' => '10%',
      'default' => true,
    ),
    'htt_diag_status' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_HTT_DIAG_STATUS',
      'width' => '10%',
      'default' => true,
    ),
    'edit_button' => 
    array (
      'widget_class' => 'SubPanelEditButton',
      'module' => 'CRTS1_Hardare_Test_Tracking',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'CRTS1_Hardare_Test_Tracking',
      'width' => '5%',
      'default' => true,
    ),
  ),
);