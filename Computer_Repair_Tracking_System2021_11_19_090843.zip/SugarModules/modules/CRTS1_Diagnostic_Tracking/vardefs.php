<?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
$dictionary['CRTS1_Diagnostic_Tracking'] = array(
	'table'=>'crts1_diagnostic_tracking',
	'audited'=>true,
	'fields'=>array (
  'hardware' => 
  array (
    'required' => false,
    'name' => 'hardware',
    'vname' => 'LBL_HARDWARE',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => 'Hardware component being serviced',
    'help' => 'Select the type of hardware you are having problems with',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'hardware_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'hardware_type' => 
  array (
    'required' => false,
    'name' => 'hardware_type',
    'vname' => 'LBL_HARDWARE_TYPE',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => '',
    'help' => 'The type of hardware being serviced',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'hardware_type_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'software' => 
  array (
    'required' => false,
    'name' => 'software',
    'vname' => 'LBL_SOFTWARE',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => '',
    'help' => 'The Software or Application package being serviced',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'software_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'frequency' => 
  array (
    'required' => false,
    'name' => 'frequency',
    'vname' => 'LBL_FREQUENCY',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => 'The frequency of the problem',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'frequency_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'cause' => 
  array (
    'required' => false,
    'name' => 'cause',
    'vname' => 'LBL_CAUSE',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => 'The action that is causing/caused the symtom ',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'cause_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'effect' => 
  array (
    'required' => false,
    'name' => 'effect',
    'vname' => 'LBL_EFFECT',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => '',
    'help' => 'The effect the cause is having on the equipment',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'effect_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'location' => 
  array (
    'required' => false,
    'name' => 'location',
    'vname' => 'LBL_LOCATION',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => '',
    'help' => 'The location of the occurance',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'location_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'resolution' => 
  array (
    'required' => '1',
    'name' => 'resolution',
    'vname' => 'LBL_RESOLUTION',
    'type' => 'enum',
    'massupdate' => '1',
    'default' => 'Not-Started',
    'comments' => '',
    'help' => 'The resolution of the servicing',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'resolution_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'consultation' => 
  array (
    'required' => false,
    'name' => 'consultation',
    'vname' => 'LBL_CONSULTATION',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => '',
    'help' => 'The consultation request',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'consultation_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'recommendation' => 
  array (
    'required' => false,
    'name' => 'recommendation',
    'vname' => 'LBL_RECOMMENDATION',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => '',
    'help' => 'The recommendation to resolve',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'recommendation_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'consult_method' => 
  array (
    'required' => false,
    'name' => 'consult_method',
    'vname' => 'LBL_CONSULT_METHOD',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => '',
    'help' => 'The method used to consult with the customer',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'consult_method_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'hardware_notes' => 
  array (
    'required' => false,
    'name' => 'hardware_notes',
    'vname' => 'LBL_HARDWARE_NOTES',
    'type' => 'varchar',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => '255',
  ),
  'software_notes' => 
  array (
    'required' => false,
    'name' => 'software_notes',
    'vname' => 'LBL_SOFTWARE_NOTES',
    'type' => 'varchar',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => '255',
  ),
  'diagnostic_notes' => 
  array (
    'required' => false,
    'name' => 'diagnostic_notes',
    'vname' => 'LBL_DIAGNOSTIC_NOTES',
    'type' => 'varchar',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => '255',
  ),
  'resolution_notes' => 
  array (
    'required' => false,
    'name' => 'resolution_notes',
    'vname' => 'LBL_RESOLUTION_NOTES',
    'type' => 'varchar',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => '255',
  ),
  'consultation_notes' => 
  array (
    'required' => false,
    'name' => 'consultation_notes',
    'vname' => 'LBL_CONSULTATION_NOTES',
    'type' => 'varchar',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => '255',
  ),
  'recommendation_notes' => 
  array (
    'required' => false,
    'name' => 'recommendation_notes',
    'vname' => 'LBL_RECOMMENDATION_NOTES',
    'type' => 'varchar',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => '255',
  ),
  'diagnostic_issue' => 
  array (
    'required' => false,
    'name' => 'diagnostic_issue',
    'vname' => 'LBL_DIAGNOSTIC_ISSUE',
    'type' => 'enum',
    'massupdate' => '1',
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 0,
    'len' => 100,
    'options' => 'diagnostic_issue_list',
    'studio' => 'visible',
    'dependency' => false,
  ),
  'diagnostic_date' => 
  array (
    'required' => false,
    'name' => 'diagnostic_date',
    'vname' => 'LBL_DIAGNOSTIC_DATE',
    'type' => 'date',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 0,
    'reportable' => 0,
    'display_default' => 'now',
  ),
  'completed_date' => 
  array (
    'required' => false,
    'name' => 'completed_date',
    'vname' => 'LBL_COMPLETED_DATE',
    'type' => 'date',
    'massupdate' => 0,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 0,
    'reportable' => 0,
  ),
),
	'relationships'=>array (
),
	'optimistic_lock'=>true,
);
if (!class_exists('VardefManager')){
        require_once('include/SugarObjects/VardefManager.php');
}
VardefManager::createVardef('CRTS1_Diagnostic_Tracking','CRTS1_Diagnostic_Tracking', array('basic','assignable'));