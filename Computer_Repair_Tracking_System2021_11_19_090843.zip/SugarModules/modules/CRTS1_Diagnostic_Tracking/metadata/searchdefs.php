<?php
$module_name = 'CRTS1_Diagnostic_Tracking';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'date_modified' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_modified',
      ),
      'diagnostic_date' => 
      array (
        'type' => 'date',
        'label' => 'LBL_DIAGNOSTIC_DATE',
        'width' => '10%',
        'default' => true,
        'name' => 'diagnostic_date',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'current_user_only' => 
      array (
        'name' => 'current_user_only',
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
        'default' => true,
        'width' => '10%',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'date_modified' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_modified',
      ),
      'hardware' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_HARDWARE',
        'width' => '10%',
        'default' => true,
        'name' => 'hardware',
      ),
      'hardware_type' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_HARDWARE_TYPE',
        'width' => '10%',
        'default' => true,
        'name' => 'hardware_type',
      ),
      'software' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_SOFTWARE',
        'width' => '10%',
        'default' => true,
        'name' => 'software',
      ),
      'frequency' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_FREQUENCY',
        'width' => '10%',
        'default' => true,
        'name' => 'frequency',
      ),
      'diagnostic_issue' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_DIAGNOSTIC_ISSUE',
        'width' => '10%',
        'default' => true,
        'name' => 'diagnostic_issue',
      ),
      'cause' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_CAUSE',
        'width' => '10%',
        'default' => true,
        'name' => 'cause',
      ),
      'effect' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_EFFECT',
        'width' => '10%',
        'default' => true,
        'name' => 'effect',
      ),
      'location' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_LOCATION',
        'width' => '10%',
        'default' => true,
        'name' => 'location',
      ),
      'recommendation' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_RECOMMENDATION',
        'width' => '10%',
        'default' => true,
        'name' => 'recommendation',
      ),
      'resolution' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_RESOLUTION',
        'width' => '10%',
        'default' => true,
        'name' => 'resolution',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'default' => true,
        'width' => '10%',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
