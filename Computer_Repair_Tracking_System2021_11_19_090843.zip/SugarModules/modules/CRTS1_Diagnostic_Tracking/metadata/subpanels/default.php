<?php
$module_name='CRTS1_Diagnostic_Tracking';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'CRTS1_Diagnostic_Tracking',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'assigned_user_name' => 
    array (
      'link' => 'assigned_user_link',
      'type' => 'relate',
      'vname' => 'LBL_ASSIGNED_TO_NAME',
      'width' => '10%',
      'default' => true,
    ),
    'diagnostic_issue' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_DIAGNOSTIC_ISSUE',
      'width' => '10%',
      'default' => true,
    ),
    'cause' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_CAUSE',
      'width' => '10%',
      'default' => true,
    ),
    'effect' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_EFFECT',
      'width' => '10%',
      'default' => true,
    ),
    'resolution' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_RESOLUTION',
      'width' => '10%',
      'default' => true,
    ),
    'recommendation' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_RECOMMENDATION',
      'width' => '10%',
      'default' => true,
    ),
    'diagnostic_date' => 
    array (
      'type' => 'date',
      'vname' => 'LBL_DIAGNOSTIC_DATE',
      'width' => '10%',
      'default' => true,
    ),
    'edit_button' => 
    array (
      'widget_class' => 'SubPanelEditButton',
      'module' => 'CRTS1_Diagnostic_Tracking',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'CRTS1_Diagnostic_Tracking',
      'width' => '5%',
      'default' => true,
    ),
  ),
);