<?php
$module_name = 'CRTS1_Diagnostic_Tracking';
$listViewDefs [$module_name] = 
array (
  'CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_NAME' => 
  array (
    'type' => 'relate',
    'link' => 'crts1_diagnostic_tracking_contacts',
    'label' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'DIAGNOSTIC_ISSUE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_DIAGNOSTIC_ISSUE',
    'width' => '10%',
    'default' => true,
  ),
  'CAUSE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_CAUSE',
    'width' => '10%',
    'default' => true,
  ),
  'EFFECT' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_EFFECT',
    'width' => '10%',
    'default' => true,
  ),
  'RESOLUTION' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_RESOLUTION',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'default' => true,
  ),
  'DIAGNOSTIC_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DIAGNOSTIC_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_NAME' => 
  array (
    'type' => 'relate',
    'link' => 'crts1_diagnostic_tracking_accounts',
    'label' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
    'width' => '10%',
    'default' => false,
  ),
  'CONSULTATION' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_CONSULTATION',
    'width' => '10%',
    'default' => false,
  ),
  'CONSULT_METHOD' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_CONSULT_METHOD',
    'width' => '10%',
    'default' => false,
  ),
  'RECOMMENDATION' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_RECOMMENDATION',
    'width' => '10%',
    'default' => false,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => 'modified_user_link',
    'label' => 'LBL_MODIFIED_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'LOCATION' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_LOCATION',
    'width' => '10%',
    'default' => false,
  ),
  'COMPLETED_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_COMPLETED_DATE',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'SOFTWARE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_SOFTWARE',
    'width' => '10%',
    'default' => false,
  ),
  'HARDWARE_TYPE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_HARDWARE_TYPE',
    'width' => '10%',
    'default' => false,
  ),
  'FREQUENCY' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_FREQUENCY',
    'width' => '10%',
    'default' => false,
  ),
  'CREATED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => 'created_by_link',
    'label' => 'LBL_CREATED',
    'width' => '10%',
    'default' => false,
  ),
  'HARDWARE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_HARDWARE',
    'width' => '10%',
    'default' => false,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'width' => '10%',
    'default' => false,
  ),
);
?>
