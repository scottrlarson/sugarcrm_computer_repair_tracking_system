<?php
$module_name = 'CRTS1_Consultation_Tracking';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'date_modified' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_modified',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'consultation' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_CONSULTATION',
        'width' => '10%',
        'default' => true,
        'name' => 'consultation',
      ),
      'resolution' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_RESOLUTION',
        'width' => '10%',
        'default' => true,
        'name' => 'resolution',
      ),
      'current_user_only' => 
      array (
        'name' => 'current_user_only',
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
        'default' => true,
        'width' => '10%',
      ),
      'consultation_date' => 
      array (
        'type' => 'date',
        'label' => 'LBL_CONSULTATION_DATE',
        'width' => '10%',
        'default' => true,
        'name' => 'consultation_date',
      ),
      'crts1_consultation_tracking_accounts_name' => 
      array (
        'type' => 'relate',
        'link' => 'crts1_consultation_tracking_accounts',
        'label' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'crts1_consultation_tracking_accounts_name',
      ),
      'crts1_consultation_tracking_contacts_name' => 
      array (
        'type' => 'relate',
        'link' => 'crts1_consultation_tracking_contacts',
        'label' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'crts1_consultation_tracking_contacts_name',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'date_modified' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_modified',
      ),
      'consultation' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_CONSULTATION',
        'width' => '10%',
        'default' => true,
        'name' => 'consultation',
      ),
      'consult_method' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_CONSULT_METHOD',
        'width' => '10%',
        'default' => true,
        'name' => 'consult_method',
      ),
      'consultation_notes' => 
      array (
        'type' => 'text',
        'studio' => 'visible',
        'label' => 'LBL_CONSULTATION_NOTES',
        'width' => '10%',
        'default' => true,
        'name' => 'consultation_notes',
      ),
      'recommendation' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_RECOMMENDATION',
        'width' => '10%',
        'default' => true,
        'name' => 'recommendation',
      ),
      'recommendation_notes' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_RECOMMENDATION_NOTES',
        'width' => '10%',
        'default' => true,
        'name' => 'recommendation_notes',
      ),
      'resolution' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_RESOLUTION',
        'width' => '10%',
        'default' => true,
        'name' => 'resolution',
      ),
      'crts1_consultation_tracking_accounts_name' => 
      array (
        'type' => 'relate',
        'link' => 'crts1_consultation_tracking_accounts',
        'label' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'crts1_consultation_tracking_accounts_name',
      ),
      'crts1_consultation_tracking_contacts_name' => 
      array (
        'type' => 'relate',
        'link' => 'crts1_consultation_tracking_contacts',
        'label' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'crts1_consultation_tracking_contacts_name',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'default' => true,
        'width' => '10%',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
