<?php
$module_name = 'CRTS1_Consultation_Tracking';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
          1 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'crts1_consultation_tracking_accounts_name',
          ),
          1 => 
          array (
            'name' => 'consultation_date',
            'label' => 'LBL_CONSULTATION_DATE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'completed_date',
            'label' => 'LBL_COMPLETED_DATE',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'priority',
            'studio' => 'visible',
            'label' => 'LBL_PRIORITY',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'customCode' => '{$fields.date_modified.value} {$APP.LBL_BY} {$fields.modified_by_name.value}',
            'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'crts1_consultation_tracking_contacts_name',
          ),
          1 => 
          array (
            'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
          ),
        ),
      ),
      'lbl_panel5' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'consultation_type',
            'studio' => 'visible',
            'label' => 'LBL_CONSULTATION_TYPE',
          ),
          1 => 
          array (
            'name' => 'consult_method',
            'studio' => 'visible',
            'label' => 'LBL_CONSULT_METHOD',
          ),
        ),
      ),
      'lbl_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'consultation',
            'studio' => 'visible',
            'label' => 'LBL_CONSULTATION',
          ),
          1 => 
          array (
            'name' => 'hardware_type',
            'studio' => 'visible',
            'label' => 'LBL_HARDWARE_TYPE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'hardware',
            'studio' => 'visible',
            'label' => 'LBL_HARDWARE',
          ),
          1 => 
          array (
            'name' => 'hardware_notes',
            'label' => 'LBL_HARDWARE_NOTES',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'software',
            'studio' => 'visible',
            'label' => 'LBL_SOFTWARE',
          ),
          1 => 
          array (
            'name' => 'software_notes',
            'label' => 'LBL_SOFTWARE_NOTES',
          ),
        ),
      ),
      'lbl_panel6' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'frequency',
            'studio' => 'visible',
            'label' => 'LBL_FREQUENCY',
          ),
          1 => 
          array (
            'name' => 'location',
            'studio' => 'visible',
            'label' => 'LBL_LOCATION',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'cause',
            'studio' => 'visible',
            'label' => 'LBL_CAUSE',
          ),
          1 => 
          array (
            'name' => 'effect',
            'studio' => 'visible',
            'label' => 'LBL_EFFECT',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'consultation_notes',
            'studio' => 'visible',
            'label' => 'LBL_CONSULTATION_NOTES',
          ),
        ),
      ),
      'lbl_panel4' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'resolution',
            'studio' => 'visible',
            'label' => 'LBL_RESOLUTION',
          ),
          1 => 
          array (
            'name' => 'resolution_notes',
            'label' => 'LBL_RESOLUTION_NOTES',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'recommendation',
            'studio' => 'visible',
            'label' => 'LBL_RECOMMENDATION',
          ),
          1 => 
          array (
            'name' => 'recommendation_notes',
            'label' => 'LBL_RECOMMENDATION_NOTES',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
          ),
          1 => '',
        ),
      ),
    ),
  ),
);
?>
