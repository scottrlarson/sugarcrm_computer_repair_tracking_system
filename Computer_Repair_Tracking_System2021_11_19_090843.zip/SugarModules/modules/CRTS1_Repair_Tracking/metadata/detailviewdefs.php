<?php
$module_name = 'CRTS1_Repair_Tracking';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
          1 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'crts1_repair_tracking_accounts_name',
            'label' => 'LBL_CRTS1_REPAIR_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
          ),
          1 => 
          array (
            'name' => 'crts1_repair_tracking_contacts_name',
            'label' => 'LBL_CRTS1_REPAIR_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'repair_date',
            'label' => 'LBL_REPAIR_DATE',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'date_modified',
            'customCode' => '{$fields.date_modified.value} {$APP.LBL_BY} {$fields.modified_by_name.value}',
            'label' => 'LBL_DATE_MODIFIED',
          ),
          1 => 
          array (
            'name' => 'completed_date',
            'label' => 'LBL_COMPLETED_DATE',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'crts1_repair_tracking_hsi_hardware_inventory_name',
            'label' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
          ),
        ),
      ),
      'lbl_panel3' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'hardware',
            'studio' => 'visible',
            'label' => 'LBL_HARDWARE',
          ),
          1 => 
          array (
            'name' => 'hardware_type',
            'studio' => 'visible',
            'label' => 'LBL_HARDWARE_TYPE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'hardware_notes',
            'label' => 'LBL_HARDWARE_NOTES',
          ),
          1 => 
          array (
            'name' => 'crts1_repair_tracking_hsi_hardware_inventory_name',
            'label' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
          ),
        ),
      ),
      'lbl_panel5' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'software',
            'studio' => 'visible',
            'label' => 'LBL_SOFTWARE',
          ),
          1 => 
          array (
            'name' => 'software_notes',
            'label' => 'LBL_SOFTWARE_NOTES',
          ),
        ),
      ),
      'lbl_panel4' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'frequency',
            'studio' => 'visible',
            'label' => 'LBL_FREQUENCY',
          ),
          1 => 
          array (
            'name' => 'location',
            'studio' => 'visible',
            'label' => 'LBL_LOCATION',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'diagnostic_issue',
            'studio' => 'visible',
            'label' => 'LBL_DIAGNOSTIC_ISSUE',
          ),
          1 => 
          array (
            'name' => 'diagnostic_notes',
            'label' => 'LBL_DIAGNOSTIC_NOTES',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'cause',
            'studio' => 'visible',
            'label' => 'LBL_CAUSE',
          ),
          1 => 
          array (
            'name' => 'effect',
            'studio' => 'visible',
            'label' => 'LBL_EFFECT',
          ),
        ),
      ),
      'lbl_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'resolution',
            'studio' => 'visible',
            'label' => 'LBL_RESOLUTION',
          ),
          1 => 
          array (
            'name' => 'recommendation',
            'studio' => 'visible',
            'label' => 'LBL_RECOMMENDATION',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'resolution_notes',
            'label' => 'LBL_RESOLUTION_NOTES',
          ),
          1 => 
          array (
            'name' => 'recommendation_notes',
            'label' => 'LBL_RECOMMENDATION_NOTES',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
          ),
          1 => '',
        ),
      ),
    ),
  ),
);
?>
