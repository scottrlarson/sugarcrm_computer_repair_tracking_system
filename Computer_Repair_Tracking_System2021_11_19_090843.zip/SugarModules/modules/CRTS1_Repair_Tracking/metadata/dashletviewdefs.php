<?php
$dashletData['CRTS1_Diagnostic_TrackingDashlet']['searchFields'] = array (
  'date_entered' => 
  array (
    'default' => '',
  ),
  'date_modified' => 
  array (
    'default' => '',
  ),
  'assigned_user_id' => 
  array (
    'type' => 'assigned_user_name',
    'default' => 'Scott Larson',
  ),
);
$dashletData['CRTS1_Diagnostic_TrackingDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => true,
    'name' => 'date_entered',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => false,
  ),
  'hardware' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_HARDWARE',
    'width' => '10%',
    'default' => false,
    'name' => 'hardware',
  ),
  'hardware_type' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_HARDWARE_TYPE',
    'width' => '10%',
    'default' => false,
    'name' => 'hardware_type',
  ),
  'software' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_SOFTWARE',
    'width' => '10%',
    'default' => false,
    'name' => 'software',
  ),
  'frequency' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_FREQUENCY',
    'width' => '10%',
    'default' => false,
    'name' => 'frequency',
  ),
  'diagnostic_issue' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_DIAGNOSTIC_ISSUE',
    'width' => '10%',
    'default' => false,
  ),
  'cause' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_CAUSE',
    'width' => '10%',
    'default' => false,
    'name' => 'cause',
  ),
  'effect' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_EFFECT',
    'width' => '10%',
    'default' => false,
    'name' => 'effect',
  ),
  'location' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_LOCATION',
    'width' => '10%',
    'default' => false,
    'name' => 'location',
  ),
  'resolution' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_RESOLUTION',
    'width' => '10%',
    'default' => false,
    'name' => 'resolution',
  ),
  'recommendation' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_RECOMMENDATION',
    'width' => '10%',
    'default' => false,
    'name' => 'recommendation',
  ),
);
