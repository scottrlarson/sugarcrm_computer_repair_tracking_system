<?php
$module_name = 'CRTS1_Repair_Tracking';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
          1 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'crts1_repair_tracking_contacts_name',
          ),
          1 => 
          array (
            'name' => 'crts1_repair_tracking_accounts_name',
          ),
        ),
        2 => 
        array (
          0 => '',
          1 => 
          array (
            'name' => 'repair_date',
            'label' => 'LBL_REPAIR_DATE',
          ),
        ),
        3 => 
        array (
          0 => '',
          1 => 
          array (
            'name' => 'completed_date',
            'label' => 'LBL_COMPLETED_DATE',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'crts1_repair_tracking_hsi_hardware_inventory_name',
          ),
        ),
      ),
      'lbl_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'hardware',
            'studio' => 'visible',
            'label' => 'LBL_HARDWARE',
          ),
          1 => 
          array (
            'name' => 'hardware_type',
            'studio' => 'visible',
            'label' => 'LBL_HARDWARE_TYPE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'hardware_notes',
            'label' => 'LBL_HARDWARE_NOTES',
          ),
          1 => 
          array (
            'name' => 'crts1_repair_tracking_hsi_hardware_inventory_name',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'software',
            'studio' => 'visible',
            'label' => 'LBL_SOFTWARE',
          ),
          1 => 
          array (
            'name' => 'software_notes',
            'label' => 'LBL_SOFTWARE_NOTES',
          ),
        ),
      ),
      'lbl_panel5' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'frequency',
            'studio' => 'visible',
            'label' => 'LBL_FREQUENCY',
          ),
          1 => 
          array (
            'name' => 'location',
            'studio' => 'visible',
            'label' => 'LBL_LOCATION',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'diagnostic_issue',
            'studio' => 'visible',
            'label' => 'LBL_DIAGNOSTIC_ISSUE',
          ),
          1 => 
          array (
            'name' => 'diagnostic_notes',
            'label' => 'LBL_DIAGNOSTIC_NOTES',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'cause',
            'studio' => 'visible',
            'label' => 'LBL_CAUSE',
          ),
          1 => 
          array (
            'name' => 'effect',
            'studio' => 'visible',
            'label' => 'LBL_EFFECT',
          ),
        ),
      ),
      'lbl_panel7' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'resolution',
            'studio' => 'visible',
            'label' => 'LBL_RESOLUTION',
          ),
          1 => 
          array (
            'name' => 'resolution_notes',
            'label' => 'LBL_RESOLUTION_NOTES',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'recommendation',
            'studio' => 'visible',
            'label' => 'LBL_RECOMMENDATION',
          ),
          1 => 
          array (
            'name' => 'recommendation_notes',
            'label' => 'LBL_RECOMMENDATION_NOTES',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
          ),
          1 => '',
        ),
      ),
    ),
  ),
);
?>
