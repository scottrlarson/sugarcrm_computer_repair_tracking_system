<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c3c73ventory_ida',
  'link' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c3c73ventory_ida"] = array (
  'name' => 'crts1_pc_c3c73ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_caddcontacts_ida',
  'link' => 'crts1_pc_checkup_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_caddcontacts_ida"] = array (
  'name' => 'crts1_pc_caddcontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c8744ccounts_ida',
  'link' => 'crts1_pc_checkup_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c8744ccounts_ida"] = array (
  'name' => 'crts1_pc_c8744ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c3c73ventory_ida',
  'link' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c3c73ventory_ida"] = array (
  'name' => 'crts1_pc_c3c73ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_caddcontacts_ida',
  'link' => 'crts1_pc_checkup_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_caddcontacts_ida"] = array (
  'name' => 'crts1_pc_caddcontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c8744ccounts_ida',
  'link' => 'crts1_pc_checkup_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c8744ccounts_ida"] = array (
  'name' => 'crts1_pc_c8744ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c3c73ventory_ida',
  'link' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c3c73ventory_ida"] = array (
  'name' => 'crts1_pc_c3c73ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_caddcontacts_ida',
  'link' => 'crts1_pc_checkup_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_caddcontacts_ida"] = array (
  'name' => 'crts1_pc_caddcontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c8744ccounts_ida',
  'link' => 'crts1_pc_checkup_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c8744ccounts_ida"] = array (
  'name' => 'crts1_pc_c8744ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c3c73ventory_ida',
  'link' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c3c73ventory_ida"] = array (
  'name' => 'crts1_pc_c3c73ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_caddcontacts_ida',
  'link' => 'crts1_pc_checkup_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_caddcontacts_ida"] = array (
  'name' => 'crts1_pc_caddcontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c8744ccounts_ida',
  'link' => 'crts1_pc_checkup_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c8744ccounts_ida"] = array (
  'name' => 'crts1_pc_c8744ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c3c73ventory_ida',
  'link' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c3c73ventory_ida"] = array (
  'name' => 'crts1_pc_c3c73ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_caddcontacts_ida',
  'link' => 'crts1_pc_checkup_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_caddcontacts_ida"] = array (
  'name' => 'crts1_pc_caddcontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c8744ccounts_ida',
  'link' => 'crts1_pc_checkup_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c8744ccounts_ida"] = array (
  'name' => 'crts1_pc_c8744ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c3c73ventory_ida',
  'link' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c3c73ventory_ida"] = array (
  'name' => 'crts1_pc_c3c73ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_caddcontacts_ida',
  'link' => 'crts1_pc_checkup_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_caddcontacts_ida"] = array (
  'name' => 'crts1_pc_caddcontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c8744ccounts_ida',
  'link' => 'crts1_pc_checkup_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c8744ccounts_ida"] = array (
  'name' => 'crts1_pc_c8744ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c3c73ventory_ida',
  'link' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c3c73ventory_ida"] = array (
  'name' => 'crts1_pc_c3c73ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_caddcontacts_ida',
  'link' => 'crts1_pc_checkup_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_caddcontacts_ida"] = array (
  'name' => 'crts1_pc_caddcontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c8744ccounts_ida',
  'link' => 'crts1_pc_checkup_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c8744ccounts_ida"] = array (
  'name' => 'crts1_pc_c8744ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c3c73ventory_ida',
  'link' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c3c73ventory_ida"] = array (
  'name' => 'crts1_pc_c3c73ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_caddcontacts_ida',
  'link' => 'crts1_pc_checkup_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_caddcontacts_ida"] = array (
  'name' => 'crts1_pc_caddcontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c8744ccounts_ida',
  'link' => 'crts1_pc_checkup_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c8744ccounts_ida"] = array (
  'name' => 'crts1_pc_c8744ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c3c73ventory_ida',
  'link' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c3c73ventory_ida"] = array (
  'name' => 'crts1_pc_c3c73ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_caddcontacts_ida',
  'link' => 'crts1_pc_checkup_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_caddcontacts_ida"] = array (
  'name' => 'crts1_pc_caddcontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c8744ccounts_ida',
  'link' => 'crts1_pc_checkup_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c8744ccounts_ida"] = array (
  'name' => 'crts1_pc_c8744ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c3c73ventory_ida',
  'link' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c3c73ventory_ida"] = array (
  'name' => 'crts1_pc_c3c73ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_contacts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_caddcontacts_ida',
  'link' => 'crts1_pc_checkup_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_caddcontacts_ida"] = array (
  'name' => 'crts1_pc_caddcontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_CONTACTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_checkup_tracking_accounts_name"] = array (
  'name' => 'crts1_pc_checkup_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_pc_c8744ccounts_ida',
  'link' => 'crts1_pc_checkup_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_PC_Checkup_Tracking"]["fields"]["crts1_pc_c8744ccounts_ida"] = array (
  'name' => 'crts1_pc_c8744ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_ACCOUNTS_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
