<?php
// created: 2012-02-15 13:17:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 13:17:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 13:18:07
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 13:18:07
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 13:18:49
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 13:18:49
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 13:18:51
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 13:18:51
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 13:32:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 13:32:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 13:35:09
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 13:35:09
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 14:04:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 14:04:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 14:10:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 14:10:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 14:54:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 14:54:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 14:54:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 14:54:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 14:54:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 14:54:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:08:22
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:08:22
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 15:08:22
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:08:22
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:08:22
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 15:08:22
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:10:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:10:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 15:10:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:10:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:10:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 15:10:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:11:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:11:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 15:11:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:11:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:11:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 15:11:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:30:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:30:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 15:30:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:30:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:30:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 15:30:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:30:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:30:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 15:30:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:30:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:30:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 15:30:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:30:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:30:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 15:30:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:30:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:30:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 15:30:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:35:03
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:35:03
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 15:35:03
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:35:03
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:35:03
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 15:35:03
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:40:18
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:40:18
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 15:40:18
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:40:18
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:40:18
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 15:40:18
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 16:13:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 16:13:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 16:13:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 16:13:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 16:13:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 16:13:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 20:51:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:51:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:51:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 20:51:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:51:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:51:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 20:54:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:54:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:54:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 20:54:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:54:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:54:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 20:55:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:55:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:55:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 20:55:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:55:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:55:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 11:15:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 11:15:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:47
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:47
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 11:15:47
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:47
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:47
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 11:15:47
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 11:15:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 11:15:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:25:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:25:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 11:25:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:25:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:25:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 11:25:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 12:07:28
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 12:07:28
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 12:07:28
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 12:07:28
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 12:07:28
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 12:07:28
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 12:31:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 12:31:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 12:31:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 12:31:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 12:31:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 12:31:16
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 19:32:34
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 19:32:34
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 19:32:34
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 19:32:34
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 19:32:34
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 19:32:34
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 19:44:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 19:44:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 19:44:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 19:44:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 19:44:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 19:44:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-18 00:53:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-18 00:53:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-18 00:53:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-18 00:53:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-18 00:53:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-18 00:53:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 12:48:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 12:48:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-22 12:48:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-22 12:48:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 12:48:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-22 12:48:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-22 12:48:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 12:55:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 12:55:03
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-22 12:55:03
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-22 12:55:03
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 12:55:03
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-22 12:55:03
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-22 12:55:03
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 13:01:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 13:01:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-22 13:01:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-22 13:01:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 13:01:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-22 13:01:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-22 13:01:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-23 12:35:44
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-23 12:35:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-23 12:35:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-23 12:35:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-23 12:35:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-23 12:35:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-23 12:35:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-23 12:36:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-23 12:36:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-23 12:36:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-23 12:36:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-23 12:36:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-23 12:36:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-23 12:36:33
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-29 10:17:55
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-29 10:18:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-29 10:18:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-29 10:18:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-29 10:18:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-29 10:18:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-29 10:18:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-06 12:41:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-06 12:41:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-06 12:41:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-06 12:41:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-06 12:41:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-06 12:41:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-06 12:41:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-06 13:45:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-06 13:45:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-06 13:45:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-06 13:45:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-06 13:45:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-06 13:45:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-06 13:45:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-07 22:49:45
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-07 22:49:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-07 22:49:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-07 22:49:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-07 22:49:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-07 22:49:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-07 22:49:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-12 18:56:31
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-12 18:56:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-12 18:56:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-12 18:56:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-12 18:56:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-12 18:56:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-12 18:56:32
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:27:55
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:27:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-14 13:27:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-14 13:27:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:27:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-14 13:27:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-14 13:27:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:30:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:30:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-14 13:30:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-14 13:30:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:30:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-14 13:30:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-14 13:30:35
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:33:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:33:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-14 13:33:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-14 13:33:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:33:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-14 13:33:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-14 13:33:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:49:07
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:57:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-04 11:54:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-04 11:54:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-04-04 11:54:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-04 11:54:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-04 11:54:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-04-04 11:54:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-04-04 11:54:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:39
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:40
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:40
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 13:14:40
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:40
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:40
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-04-09 13:14:40
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:40
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:40
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 13:14:40
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 13:21:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-04-09 13:21:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 13:21:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:27
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:28
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:28
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 14:44:28
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:28
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:28
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-04-09 14:44:28
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:29
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:29
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 14:44:29
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:22
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:23
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:23
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 14:45:23
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:23
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:23
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-04-09 14:45:23
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:23
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:23
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 14:45:23
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:02
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-05-03 14:19:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-05-03 14:19:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-05-03 14:19:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:41
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-05-03 19:19:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-05-03 19:19:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-05-03 19:19:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:06
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:07
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:07
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:17:07
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:07
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:07
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-06-05 19:17:07
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:07
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:07
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:17:07
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:29
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:30
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:30
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:21:30
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:30
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:30
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-06-05 19:21:30
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:30
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:30
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:21:30
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:42:59
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:43:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:43:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:43:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:43:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:43:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-06-05 19:43:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:43:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-06-05 19:43:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:43:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:14
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:45:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-06-05 19:45:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:45:15
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:38
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:39
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:39
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-07-31 13:43:39
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:39
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:39
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-07-31 13:43:39
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:39
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:39
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-07-31 13:43:39
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:18
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-07-31 13:44:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-07-31 13:44:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-07-31 13:44:19
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:06:00
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:06:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-08-16 16:06:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-08-16 16:06:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:06:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-08-16 16:06:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-08-16 16:06:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:06:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-08-16 16:06:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-08-16 16:06:01
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:55
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'name' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-08-16 16:28:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-08-16 16:28:56
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:57
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:57
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-08-16 16:28:57
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-08-16 16:31:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-08-16 16:31:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-08-16 16:31:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-05 14:06:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-05 14:06:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-05 14:06:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:58:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-11 12:58:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:58:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:38
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:38
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:59:38
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:38
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:38
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-11 12:59:38
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:38
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:38
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:59:38
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:59:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-11 12:59:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:59:42
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-10-16 08:15:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-10-16 08:15:05
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:06
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:06
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-10-16 08:15:06
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2014-02-04 10:17:37
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:48
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:48
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:54:48
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:48
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:48
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2018-10-08 13:54:48
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:48
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:48
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:54:48
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-05-07 12:33:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-05-07 12:33:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2021-05-07 12:33:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_accounts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag2553ccounts_ida',
  'link' => 'crts1_diagnostic_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag2553ccounts_ida"] = array (
  'name' => 'crts1_diag2553ccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_contacts_name"] = array (
  'name' => 'crts1_diagnostic_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_diag7bfdontacts_ida',
  'link' => 'crts1_diagnostic_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diag7bfdontacts_ida"] = array (
  'name' => 'crts1_diag7bfdontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_diagc8fbventory_ida',
  'link' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Diagnostic_Tracking"]["fields"]["crts1_diagc8fbventory_ida"] = array (
  'name' => 'crts1_diagc8fbventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
