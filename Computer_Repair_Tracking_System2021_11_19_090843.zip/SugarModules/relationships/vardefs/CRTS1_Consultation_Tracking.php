<?php
// created: 2012-02-15 15:35:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:35:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 15:35:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:35:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:35:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 15:35:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:40:18
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:40:18
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 15:40:18
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 15:40:18
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 15:40:18
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 15:40:18
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 16:13:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 16:13:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 16:13:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 16:13:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 16:13:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 16:13:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 20:51:15
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:51:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:51:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 20:51:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:51:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:51:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 20:54:45
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:54:45
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:54:45
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 20:54:45
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:54:45
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:54:45
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 20:55:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:55:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-15 20:55:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-15 20:55:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-15 20:55:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-15 20:55:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 11:15:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 11:15:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 11:15:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 11:15:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 11:15:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:15:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 11:15:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:25:02
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:25:02
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 11:25:02
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 11:25:02
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 11:25:02
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 11:25:02
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 12:07:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 12:07:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 12:07:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 12:07:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 12:07:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 12:07:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 12:31:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 12:31:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 12:31:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 12:31:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 12:31:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 12:31:16
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 19:32:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 19:32:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 19:32:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 19:32:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 19:32:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 19:32:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 19:44:02
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-16 19:44:02
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-16 19:44:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-16 19:44:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-16 19:44:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-16 19:44:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-18 00:53:20
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-18 00:53:20
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-18 00:53:20
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-18 00:53:20
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-18 00:53:20
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-18 00:53:20
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 12:48:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-22 12:48:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-22 12:48:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 12:48:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-22 12:48:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-22 12:48:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 12:55:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-22 12:55:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-22 12:55:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 12:55:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-22 12:55:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-22 12:55:03
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 13:01:32
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-22 13:01:32
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-22 13:01:32
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-22 13:01:32
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-22 13:01:32
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-22 13:01:33
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-23 12:35:45
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-23 12:35:45
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-23 12:35:45
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-23 12:35:45
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-23 12:35:45
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-23 12:35:45
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-23 12:36:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-23 12:36:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-23 12:36:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-23 12:36:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-23 12:36:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-23 12:36:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-29 10:18:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-02-29 10:18:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-02-29 10:18:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-02-29 10:18:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-02-29 10:18:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-02-29 10:18:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-06 12:41:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-06 12:41:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-06 12:41:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-06 12:41:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-06 12:41:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-06 12:41:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-06 13:45:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-06 13:45:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-06 13:45:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-06 13:45:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-06 13:45:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-06 13:45:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-07 22:48:31
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-07 22:49:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-07 22:49:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-07 22:49:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-07 22:49:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-07 22:49:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-07 22:49:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-12 18:56:32
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-12 18:56:32
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-12 18:56:32
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-12 18:56:32
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-12 18:56:32
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-12 18:56:32
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-12 19:07:00
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:27:56
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-14 13:27:56
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-14 13:27:56
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:27:56
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-14 13:27:56
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-14 13:27:56
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:30:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-14 13:30:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-14 13:30:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:30:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-14 13:30:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-14 13:30:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:33:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-14 13:33:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-14 13:33:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-14 13:33:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-14 13:33:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-14 13:33:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-04 11:53:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-04-04 11:53:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-04 11:53:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-04 11:53:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-04-04 11:53:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-04-04 11:53:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-04 11:53:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-04-04 11:53:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-04 11:53:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 13:14:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-04-09 13:14:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 13:14:38
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 13:21:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-04-09 13:21:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 13:21:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:27
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:27
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 14:44:27
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:27
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:27
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-04-09 14:44:27
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:27
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:27
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 14:44:27
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:21
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:21
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 14:45:21
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:21
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:21
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-04-09 14:45:21
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:21
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:21
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-04-09 14:45:21
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-05-03 14:19:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-05-03 14:19:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-05-03 14:19:01
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-05-03 19:19:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-05-03 19:19:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-05-03 19:19:41
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:17:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-06-05 19:17:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:17:05
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:21:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-06-05 19:21:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:21:28
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:42:58
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:42:58
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:42:58
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:42:58
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:42:58
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-06-05 19:42:58
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:42:58
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-06-05 19:42:58
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:42:58
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:45:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-06-05 19:45:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-06-05 19:45:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-07-31 13:43:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-07-31 13:43:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-07-31 13:43:37
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-07-31 13:44:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-07-31 13:44:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-07-31 13:44:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:05:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-08-16 16:05:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-08-16 16:05:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:05:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-08-16 16:05:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-08-16 16:05:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:05:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-08-16 16:05:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-08-16 16:05:59
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:54
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:54
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-08-16 16:28:54
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:54
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:54
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-08-16 16:28:54
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:55
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:55
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-08-16 16:28:55
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-08-16 16:31:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-08-16 16:31:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-08-16 16:31:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-05 14:06:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-05 14:06:34
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:35
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:35
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-05 14:06:35
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:58:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:58:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-11 12:58:24
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:59:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:59:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-11 12:59:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:40
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:40
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:59:40
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:40
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:40
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-09-11 12:59:40
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:40
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:40
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-09-11 12:59:40
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2012-10-16 08:15:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2012-10-16 08:15:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2012-10-16 08:15:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:53
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:53
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-05-07 12:34:53
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:53
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:53
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2021-05-07 12:34:53
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:53
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:53
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-05-07 12:34:53
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts"] = array (
  'name' => 'crts1_consultation_tracking_accounts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_accounts_name"] = array (
  'name' => 'crts1_consultation_tracking_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf54eccounts_ida',
  'link' => 'crts1_consultation_tracking_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consf54eccounts_ida"] = array (
  'name' => 'crts1_consf54eccounts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_ACCOUNTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'save' => true,
  'id_name' => 'crts1_cons7b65ventory_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'hsi_hardware_inventory',
  'module' => 'hsi_Hardware_Inventory',
  'rname' => 'name',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_cons7b65ventory_ida"] = array (
  'name' => 'crts1_cons7b65ventory_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts"] = array (
  'name' => 'crts1_consultation_tracking_contacts',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consultation_tracking_contacts_name"] = array (
  'name' => 'crts1_consultation_tracking_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'crts1_consc05eontacts_ida',
  'link' => 'crts1_consultation_tracking_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["CRTS1_Consultation_Tracking"]["fields"]["crts1_consc05eontacts_ida"] = array (
  'name' => 'crts1_consc05eontacts_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_CONTACTS_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
