<?php
// created: 2012-03-22 13:47:15
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf07fracking_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'crts1_consultation_tracking',
  'module' => 'CRTS1_Consultation_Tracking',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-22 13:47:15
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consf07fracking_ida"] = array (
  'name' => 'crts1_consf07fracking_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory_name"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'save' => true,
  'id_name' => 'crts1_consf07fracking_ida',
  'link' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'table' => 'crts1_consultation_tracking',
  'module' => 'CRTS1_Consultation_Tracking',
  'rname' => 'name',
);
?>
<?php
// created: 2012-03-22 13:49:08
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consf07fracking_ida"] = array (
  'name' => 'crts1_consf07fracking_ida',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
);
?>
<?php
// created: 2012-03-22 13:54:08
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-03-22 13:57:06
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-04 11:53:59
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:38
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:14:40
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:43
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 13:21:43
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:27
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:28
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:44:29
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:21
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:22
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-04-09 14:45:23
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:01
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:03
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 14:19:04
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:42
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-05-03 19:19:43
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:06
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:17:07
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:28
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:30
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:21:30
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:42:58
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:43:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:43:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:13
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:14
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-06-05 19:45:15
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:39
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:43:39
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:17
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:19
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-07-31 13:44:19
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:05:59
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:06:00
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:06:01
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:54
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:56
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:28:57
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:24
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:25
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-08-16 16:31:26
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:34
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:36
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-05 14:06:36
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:24
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:25
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:58:26
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:36
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:38
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:40
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:41
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-09-11 12:59:42
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:04
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:05
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2012-10-16 08:15:06
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:17
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:56
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2013-12-13 15:14:57
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:36
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2014-02-04 10:17:37
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:05:26
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:12
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2014-06-04 12:14:13
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2016-05-23 16:06:52
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2016-11-25 16:23:46
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:03
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:04
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:47
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:54:48
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:55:11
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2018-10-08 13:56:55
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:09
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:33:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:53
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:53
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2021-05-07 12:34:54
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-02 14:57:10
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
);
?>
<?php
// created: 2021-11-19 09:08:43
$dictionary["hsi_Hardware_Inventory"]["fields"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'name' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'type' => 'link',
  'relationship' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'source' => 'non-db',
  'vname' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
);
?>
