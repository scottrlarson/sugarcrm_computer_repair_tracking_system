<?php
// created: 2021-11-19 09:08:43
$dictionary["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'crts1_diagnostic_tracking_hsi_hardware_inventory' => 
    array (
      'lhs_module' => 'hsi_Hardware_Inventory',
      'lhs_table' => 'hsi_hardware_inventory',
      'lhs_key' => 'id',
      'rhs_module' => 'CRTS1_Diagnostic_Tracking',
      'rhs_table' => 'crts1_diagnostic_tracking',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'crts1_diagnre_inventory_c',
      'join_key_lhs' => 'crts1_diagc8fbventory_ida',
      'join_key_rhs' => 'crts1_diag18ccracking_idb',
    ),
  ),
  'table' => 'crts1_diagnre_inventory_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'crts1_diagc8fbventory_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'crts1_diag18ccracking_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'crts1_diagnware_inventoryspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'crts1_diagnware_inventory_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'crts1_diagc8fbventory_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'crts1_diagnware_inventory_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'crts1_diag18ccracking_idb',
      ),
    ),
  ),
);
?>
