<?php
// created: 2021-11-19 09:08:43
$dictionary["crts1_pc_checkup_tracking_contacts"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'crts1_pc_checkup_tracking_contacts' => 
    array (
      'lhs_module' => 'Contacts',
      'lhs_table' => 'contacts',
      'lhs_key' => 'id',
      'rhs_module' => 'CRTS1_PC_Checkup_Tracking',
      'rhs_table' => 'crts1_pc_checkup_tracking',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'crts1_pc_ching_contacts_c',
      'join_key_lhs' => 'crts1_pc_caddcontacts_ida',
      'join_key_rhs' => 'crts1_pc_cc409racking_idb',
    ),
  ),
  'table' => 'crts1_pc_ching_contacts_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'crts1_pc_caddcontacts_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'crts1_pc_cc409racking_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'crts1_pc_chcking_contactsspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'crts1_pc_chcking_contacts_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'crts1_pc_caddcontacts_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'crts1_pc_chcking_contacts_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'crts1_pc_cc409racking_idb',
      ),
    ),
  ),
);
?>
