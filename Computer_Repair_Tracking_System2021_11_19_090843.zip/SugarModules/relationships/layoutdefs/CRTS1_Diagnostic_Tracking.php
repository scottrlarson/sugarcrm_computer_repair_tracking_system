<?php
// created: 2012-02-15 13:17:02
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_accounts"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 13:17:02
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 13:18:07
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_accounts"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 13:18:07
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 13:18:49
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_accounts"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 13:18:49
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 13:18:51
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_accounts"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 13:18:51
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 13:32:16
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_accounts"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 13:32:16
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 13:35:09
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_accounts"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 13:35:09
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 14:04:05
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_accounts"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 14:04:05
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 14:10:52
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_accounts"] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-15 14:10:52
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_diagnostic_tracking_contacts"] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_CONTACTS_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-22 12:48:01
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-22 12:55:02
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-22 13:01:31
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-23 12:35:44
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-23 12:36:33
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-02-29 10:17:55
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-06 12:41:37
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-06 13:45:04
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-07 22:48:31
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-07 22:49:45
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-12 18:56:31
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-12 19:07:00
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-14 13:27:55
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-14 13:30:35
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-14 13:33:04
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-22 13:47:15
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-22 13:49:07
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-22 13:54:08
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-22 13:57:05
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-04 11:54:00
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 13:14:39
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 13:21:42
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 14:44:27
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 14:45:22
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-05-03 14:19:02
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-05-03 19:19:41
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:17:06
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:21:29
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:42:59
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:45:13
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-07-31 13:43:38
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-07-31 13:44:18
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-08-16 16:05:59
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-08-16 16:28:55
$layout_defs["CRTS1_Diagnostic_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_diagnostic_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_DIAGNOSTIC_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_diagnostic_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
