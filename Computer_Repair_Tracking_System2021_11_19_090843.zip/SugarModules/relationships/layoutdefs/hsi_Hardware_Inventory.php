<?php
// created: 2012-03-22 13:54:08
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-22 13:57:06
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-04 11:53:59
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 13:14:38
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 13:14:40
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 13:21:41
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 13:21:42
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 13:21:43
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 14:44:27
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 14:44:28
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 14:44:28
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 14:45:21
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 14:45:22
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-04-09 14:45:23
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-05-03 14:19:01
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-05-03 14:19:03
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-05-03 14:19:04
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-05-03 19:19:41
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-05-03 19:19:42
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-05-03 19:19:43
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:17:05
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:17:06
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:17:07
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:21:28
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:21:29
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:21:30
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:42:58
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:42:59
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:43:00
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:45:13
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:45:14
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-06-05 19:45:15
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-07-31 13:43:37
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-07-31 13:43:38
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-07-31 13:43:39
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-07-31 13:44:17
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-07-31 13:44:18
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-07-31 13:44:19
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-08-16 16:05:59
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-08-16 16:06:00
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-08-16 16:06:01
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-08-16 16:28:54
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-08-16 16:28:56
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-08-16 16:28:56
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-08-16 16:31:24
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-08-16 16:31:25
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-08-16 16:31:25
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-05 14:06:34
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-05 14:06:35
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-05 14:06:36
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-11 12:58:24
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-11 12:58:25
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-11 12:58:25
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-11 12:59:36
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-11 12:59:37
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-11 12:59:38
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-11 12:59:40
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-11 12:59:41
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-09-11 12:59:42
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-10-16 08:15:03
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-10-16 08:15:05
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-10-16 08:15:05
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2013-12-13 15:14:17
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2013-12-13 15:14:17
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2013-12-13 15:14:17
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2013-12-13 15:14:56
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2013-12-13 15:14:57
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2013-12-13 15:14:57
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-02-04 10:17:36
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-02-04 10:17:36
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-02-04 10:17:36
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-06-04 12:05:26
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-06-04 12:05:26
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-06-04 12:05:26
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-06-04 12:14:12
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-06-04 12:14:13
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2014-06-04 12:14:13
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2016-05-23 16:06:52
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2016-05-23 16:06:52
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2016-05-23 16:06:52
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_PC_Checkup_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2016-05-23 16:06:52
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2016-11-25 16:23:46
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2016-11-25 16:23:46
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2016-11-25 16:23:46
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_PC_Checkup_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2016-11-25 16:23:46
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:54:03
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:54:03
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:54:04
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_PC_Checkup_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:54:04
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:54:04
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:54:47
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:54:47
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:54:47
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_PC_Checkup_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:54:47
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:54:47
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:55:11
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:55:11
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:55:11
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_PC_Checkup_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:55:11
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:55:11
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:56:55
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:56:55
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:56:55
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_PC_Checkup_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:56:55
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:56:55
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-05-07 12:33:09
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-05-07 12:33:09
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-05-07 12:33:09
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_PC_Checkup_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-05-07 12:33:09
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-05-07 12:33:10
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-05-07 12:34:53
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-05-07 12:34:53
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-05-07 12:34:54
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_PC_Checkup_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-05-07 12:34:54
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-05-07 12:34:54
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-11-02 14:57:10
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-11-02 14:57:10
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-11-02 14:57:10
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_PC_Checkup_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-11-02 14:57:10
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-11-02 14:57:10
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-11-19 09:08:43
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_repair_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Repair_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_REPAIR_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_REPAIR_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_repair_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-11-19 09:08:43
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Consultation_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_CONSULTATION_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-11-19 09:08:43
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_pc_checkup_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_PC_Checkup_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_PC_CHECKUP_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_PC_CHECKUP_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_pc_checkup_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-11-19 09:08:43
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_hardare_test_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_HARDARE_TEST_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2021-11-19 09:08:43
$layout_defs["hsi_Hardware_Inventory"]["subpanel_setup"]["crts1_diagnostic_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'CRTS1_Diagnostic_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_DIAGNOSTIC_TRACKING_HSI_HARDWARE_INVENTORY_FROM_CRTS1_DIAGNOSTIC_TRACKING_TITLE',
  'get_subpanel_data' => 'crts1_diagnostic_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
