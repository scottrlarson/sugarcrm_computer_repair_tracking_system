<?php
// created: 2018-10-08 13:54:04
$layout_defs["CRTS1_Hardare_Test_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_hardare_test_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_HARDARE_TEST_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_R_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_hardare_test_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:54:47
$layout_defs["CRTS1_Hardare_Test_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_hardare_test_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_HARDARE_TEST_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_R_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_hardare_test_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2018-10-08 13:55:11
$layout_defs["CRTS1_Hardare_Test_Tracking"]["subpanel_setup"]["crts1_hardare_test_tracking_crts1_hardare_test_tracking"] = array (
  'order' => 100,
  'module' => 'CRTS1_Hardare_Test_Tracking',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_HARDARE_TEST_TRACKING_CRTS1_HARDARE_TEST_TRACKING_FROM_CRTS1_HARDARE_TEST_TRACKING_R_TITLE',
  'get_subpanel_data' => 'crts1_hardare_test_tracking_crts1_hardare_test_tracking',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
