<?php
// created: 2012-03-22 13:47:15
$layout_defs["CRTS1_Consultation_Tracking"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2012-03-22 13:49:08
$layout_defs["CRTS1_Consultation_Tracking"]["subpanel_setup"]["crts1_consultation_tracking_hsi_hardware_inventory"] = array (
  'order' => 100,
  'module' => 'hsi_Hardware_Inventory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CRTS1_CONSULTATION_TRACKING_HSI_HARDWARE_INVENTORY_FROM_HSI_HARDWARE_INVENTORY_TITLE',
  'get_subpanel_data' => 'crts1_consultation_tracking_hsi_hardware_inventory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
