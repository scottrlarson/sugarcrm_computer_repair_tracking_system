    <?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

    $manifest = array (
         'acceptable_sugar_versions' => 
          array (
            
          ),
          'acceptable_sugar_flavors' =>
          array(
            'CE', 'PRO','ENT'
          ),
          'readme'=>'',
          'key'=>'CRTS1',
          'author' => 'Scott',
          'description' => 'A set of tools to track Computer Diagnostic and Repair Jobs.',
          'icon' => '',
          'is_uninstallable' => true,
          'name' => 'Computer_Repair_Tracking_System',
          'published_date' => '2021-11-19 17:08:43',
          'type' => 'module',
          'version' => '1637341723',
          'remove_tables' => 'prompt',
          );
$installdefs = array (
  'id' => 'Computer_Repair_Tracking_System',
  'beans' => 
  array (
    0 => 
    array (
      'module' => 'CRTS1_Repair_Tracking',
      'class' => 'CRTS1_Repair_Tracking',
      'path' => 'modules/CRTS1_Repair_Tracking/CRTS1_Repair_Tracking.php',
      'tab' => true,
    ),
    1 => 
    array (
      'module' => 'CRTS1_Consultation_Tracking',
      'class' => 'CRTS1_Consultation_Tracking',
      'path' => 'modules/CRTS1_Consultation_Tracking/CRTS1_Consultation_Tracking.php',
      'tab' => true,
    ),
    2 => 
    array (
      'module' => 'CRTS1_PC_Checkup_Tracking',
      'class' => 'CRTS1_PC_Checkup_Tracking',
      'path' => 'modules/CRTS1_PC_Checkup_Tracking/CRTS1_PC_Checkup_Tracking.php',
      'tab' => true,
    ),
    3 => 
    array (
      'module' => 'CRTS1_Hardare_Test_Tracking',
      'class' => 'CRTS1_Hardare_Test_Tracking',
      'path' => 'modules/CRTS1_Hardare_Test_Tracking/CRTS1_Hardare_Test_Tracking.php',
      'tab' => true,
    ),
    4 => 
    array (
      'module' => 'CRTS1_Diagnostic_Tracking',
      'class' => 'CRTS1_Diagnostic_Tracking',
      'path' => 'modules/CRTS1_Diagnostic_Tracking/CRTS1_Diagnostic_Tracking.php',
      'tab' => true,
    ),
  ),
  'layoutdefs' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Contacts.php',
      'to_module' => 'Contacts',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Contacts.php',
      'to_module' => 'Contacts',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
    ),
    7 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Contacts.php',
      'to_module' => 'Contacts',
    ),
    8 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    9 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    10 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Contacts.php',
      'to_module' => 'Contacts',
    ),
    11 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
    ),
    12 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    13 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Contacts.php',
      'to_module' => 'Contacts',
    ),
    14 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
    ),
  ),
  'relationships' => 
  array (
    0 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_repair_tracking_accountsMetaData.php',
    ),
    1 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_repair_tracking_contactsMetaData.php',
    ),
    2 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_repair_tracking_hsi_hardware_inventoryMetaData.php',
    ),
    3 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_consultation_tracking_accountsMetaData.php',
    ),
    4 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_consultation_tracking_hsi_hardware_inventoryMetaData.php',
    ),
    5 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_consultation_tracking_contactsMetaData.php',
    ),
    6 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_pc_checkup_tracking_hsi_hardware_inventoryMetaData.php',
    ),
    7 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_pc_checkup_tracking_contactsMetaData.php',
    ),
    8 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_pc_checkup_tracking_accountsMetaData.php',
    ),
    9 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_hardare_test_tracking_accountsMetaData.php',
    ),
    10 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_hardare_test_tracking_contactsMetaData.php',
    ),
    11 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_hardare_test_tracking_hsi_hardware_inventoryMetaData.php',
    ),
    12 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_diagnostic_tracking_accountsMetaData.php',
    ),
    13 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_diagnostic_tracking_contactsMetaData.php',
    ),
    14 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/crts1_diagnostic_tracking_hsi_hardware_inventoryMetaData.php',
    ),
  ),
  'image_dir' => '<basepath>/icons',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/modules/CRTS1_Repair_Tracking',
      'to' => 'modules/CRTS1_Repair_Tracking',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/modules/CRTS1_Consultation_Tracking',
      'to' => 'modules/CRTS1_Consultation_Tracking',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/modules/CRTS1_PC_Checkup_Tracking',
      'to' => 'modules/CRTS1_PC_Checkup_Tracking',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/modules/CRTS1_Hardare_Test_Tracking',
      'to' => 'modules/CRTS1_Hardare_Test_Tracking',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/modules/CRTS1_Diagnostic_Tracking',
      'to' => 'modules/CRTS1_Diagnostic_Tracking',
    ),
  ),
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_Repair_Tracking.php',
      'to_module' => 'CRTS1_Repair_Tracking',
      'language' => 'en_us',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Accounts.php',
      'to_module' => 'Accounts',
      'language' => 'en_us',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_Repair_Tracking.php',
      'to_module' => 'CRTS1_Repair_Tracking',
      'language' => 'en_us',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Contacts.php',
      'to_module' => 'Contacts',
      'language' => 'en_us',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_Repair_Tracking.php',
      'to_module' => 'CRTS1_Repair_Tracking',
      'language' => 'en_us',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
      'language' => 'en_us',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_Consultation_Tracking.php',
      'to_module' => 'CRTS1_Consultation_Tracking',
      'language' => 'en_us',
    ),
    7 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Accounts.php',
      'to_module' => 'Accounts',
      'language' => 'en_us',
    ),
    8 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_Consultation_Tracking.php',
      'to_module' => 'CRTS1_Consultation_Tracking',
      'language' => 'en_us',
    ),
    9 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
      'language' => 'en_us',
    ),
    10 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_Consultation_Tracking.php',
      'to_module' => 'CRTS1_Consultation_Tracking',
      'language' => 'en_us',
    ),
    11 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Contacts.php',
      'to_module' => 'Contacts',
      'language' => 'en_us',
    ),
    12 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_PC_Checkup_Tracking.php',
      'to_module' => 'CRTS1_PC_Checkup_Tracking',
      'language' => 'en_us',
    ),
    13 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
      'language' => 'en_us',
    ),
    14 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_PC_Checkup_Tracking.php',
      'to_module' => 'CRTS1_PC_Checkup_Tracking',
      'language' => 'en_us',
    ),
    15 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Contacts.php',
      'to_module' => 'Contacts',
      'language' => 'en_us',
    ),
    16 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_PC_Checkup_Tracking.php',
      'to_module' => 'CRTS1_PC_Checkup_Tracking',
      'language' => 'en_us',
    ),
    17 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Accounts.php',
      'to_module' => 'Accounts',
      'language' => 'en_us',
    ),
    18 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_Hardare_Test_Tracking.php',
      'to_module' => 'CRTS1_Hardare_Test_Tracking',
      'language' => 'en_us',
    ),
    19 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Accounts.php',
      'to_module' => 'Accounts',
      'language' => 'en_us',
    ),
    20 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_Hardare_Test_Tracking.php',
      'to_module' => 'CRTS1_Hardare_Test_Tracking',
      'language' => 'en_us',
    ),
    21 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Contacts.php',
      'to_module' => 'Contacts',
      'language' => 'en_us',
    ),
    22 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_Hardare_Test_Tracking.php',
      'to_module' => 'CRTS1_Hardare_Test_Tracking',
      'language' => 'en_us',
    ),
    23 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
      'language' => 'en_us',
    ),
    24 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_Diagnostic_Tracking.php',
      'to_module' => 'CRTS1_Diagnostic_Tracking',
      'language' => 'en_us',
    ),
    25 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Accounts.php',
      'to_module' => 'Accounts',
      'language' => 'en_us',
    ),
    26 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_Diagnostic_Tracking.php',
      'to_module' => 'CRTS1_Diagnostic_Tracking',
      'language' => 'en_us',
    ),
    27 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Contacts.php',
      'to_module' => 'Contacts',
      'language' => 'en_us',
    ),
    28 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/CRTS1_Diagnostic_Tracking.php',
      'to_module' => 'CRTS1_Diagnostic_Tracking',
      'language' => 'en_us',
    ),
    29 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
      'language' => 'en_us',
    ),
    30 => 
    array (
      'from' => '<basepath>/SugarModules/language/application/en_us.lang.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
  ),
  'vardefs' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_Repair_Tracking.php',
      'to_module' => 'CRTS1_Repair_Tracking',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_Repair_Tracking.php',
      'to_module' => 'CRTS1_Repair_Tracking',
    ),
    3 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Contacts.php',
      'to_module' => 'Contacts',
    ),
    4 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_Repair_Tracking.php',
      'to_module' => 'CRTS1_Repair_Tracking',
    ),
    5 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
    ),
    6 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_Consultation_Tracking.php',
      'to_module' => 'CRTS1_Consultation_Tracking',
    ),
    7 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    8 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_Consultation_Tracking.php',
      'to_module' => 'CRTS1_Consultation_Tracking',
    ),
    9 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
    ),
    10 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_Consultation_Tracking.php',
      'to_module' => 'CRTS1_Consultation_Tracking',
    ),
    11 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Contacts.php',
      'to_module' => 'Contacts',
    ),
    12 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_PC_Checkup_Tracking.php',
      'to_module' => 'CRTS1_PC_Checkup_Tracking',
    ),
    13 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
    ),
    14 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_PC_Checkup_Tracking.php',
      'to_module' => 'CRTS1_PC_Checkup_Tracking',
    ),
    15 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Contacts.php',
      'to_module' => 'Contacts',
    ),
    16 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_PC_Checkup_Tracking.php',
      'to_module' => 'CRTS1_PC_Checkup_Tracking',
    ),
    17 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    18 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_Hardare_Test_Tracking.php',
      'to_module' => 'CRTS1_Hardare_Test_Tracking',
    ),
    19 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    20 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_Hardare_Test_Tracking.php',
      'to_module' => 'CRTS1_Hardare_Test_Tracking',
    ),
    21 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Contacts.php',
      'to_module' => 'Contacts',
    ),
    22 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_Hardare_Test_Tracking.php',
      'to_module' => 'CRTS1_Hardare_Test_Tracking',
    ),
    23 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
    ),
    24 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_Diagnostic_Tracking.php',
      'to_module' => 'CRTS1_Diagnostic_Tracking',
    ),
    25 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Accounts.php',
      'to_module' => 'Accounts',
    ),
    26 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_Diagnostic_Tracking.php',
      'to_module' => 'CRTS1_Diagnostic_Tracking',
    ),
    27 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/Contacts.php',
      'to_module' => 'Contacts',
    ),
    28 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/CRTS1_Diagnostic_Tracking.php',
      'to_module' => 'CRTS1_Diagnostic_Tracking',
    ),
    29 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/hsi_Hardware_Inventory.php',
      'to_module' => 'hsi_Hardware_Inventory',
    ),
  ),
  'layoutfields' => 
  array (
    0 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    1 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    2 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    3 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    4 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    5 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    6 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    7 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    8 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    9 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    10 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    11 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    12 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    13 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
    14 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
  ),
);